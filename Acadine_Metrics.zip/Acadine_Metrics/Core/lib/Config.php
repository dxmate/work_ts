<?php

namespace Core\lib;

use Core\common\Singleton;

/**
 * This class is used to load default config from $_ENV.
 */
class Config extends Singleton
{
    private static $config;

    public function __construct()
    {
        if (is_null(self::$config)) {
            $dotenv_file = '.env';
            if (!empty($_ENV['DOTENV_FILE'])) {
                $dotenv_file = $_ENV['DOTENV_FILE'];
            }
            $docenv = new \Dotenv\Dotenv(APP_PATH, $dotenv_file);
            $docenv->load();
            $this->defaultConfig();
        }
    }

    /**
     * load default class.
     */
    private function defaultConfig()
    {
        self::$config = [
            'debug' => $_ENV['DEBUG'] == 'true' ? true : false,
            'mode' => $_ENV['MODE'],
            'redis.config' => [
                'db' => [
                    'scheme' => 'tcp',
                    'host' => $_ENV['REDIS_DB_SERVER_HOST'],
                    'port' => $_ENV['REDIS_DB_SERVER_PORT'],
                ],
                'cache' => [
                    'scheme' => 'tcp',
                    'host' => $_ENV['REDIS_CACHE_SERVER_HOST'],
                    'port' => $_ENV['REDIS_CACHE_SERVER_PORT'],
                ],
            ],
            'log.config' => [
                'file.path' => $_ENV['LOGGER_PATH'],
                'level' => $_ENV['LOGGER_LEVEL'],
            ],
            'cookies.lifetime' => $_ENV['COOKIES_LIFETIME'],
        ];
    }

    /**
     * get config.
     *
     * @param string $name
     */
    public static function get(string $name)
    {
        self::getInstance();

        return isset(self::$config[$name]) ? self::$config[$name] : (isset($_ENV[$name]) ? $_ENV[$name] : '');
    }

    /**
     * add config.
     *
     * @param string $name
     * @param mix    $value
     */
    public static function set(string $name, $value)
    {
        self::$config[$name] = $value;
    }
}
