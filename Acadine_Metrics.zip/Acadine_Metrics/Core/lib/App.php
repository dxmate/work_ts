<?php

namespace Core\lib;

/**
 * This class is used to dispatch the request.
 */
class App
{
    private $module;

    private $controller;

    private $action;

    private $app;

    private static $instance;

    public function __construct(\Slim\Slim $app)
    {
        $this->app = $app;

        // Config init
        Config::getInstance();

        // default route handler
        $this->route();
    }

    /**
     * @param \Slim\Slim $app
     */
    public static function init(\Slim\Slim $app)
    {
        self::$instance = new self($app);
    }

    /**
     * @return \Core\lib\App
     */
    public static function getInstance()
    {
        return self::$instance;
    }

    /**
     * default route handler.
     */
    private function route()
    {
        $this->app->map('/:module/:controller/:actions+', function ($module, $controller, $actions) {
            $this->module = $module;
            $this->controller = $controller;
            $this->action = $actions[0];
            array_shift($actions);
            $class = '\\Module\\'.$this->module.'\\controller\\'.ucfirst($this->controller);
            if (class_exists($class)) {
                $ctl = new $class();
                try {
                    if (method_exists($ctl, 'beforeAction')) {
                        $ctl->beforeAction($this->app, $actions);
                    }
                    if (method_exists($ctl, $this->action)) {
                        $method = new \ReflectionMethod($ctl, $this->action);
                        if ($method->isPublic() && !$method->isStatic()) {
                            $method->invoke($ctl, $actions);
                            if (method_exists($ctl, 'afterAction')) {
                                $ctl->afterAction(null);
                            }

                            return;
                        }
                    }
                } catch (\Exception $e) {
                    if (method_exists($ctl, 'afterAction')) {
                        $ctl->afterAction($e);

                        return;
                    } else {
                        throw $e;
                    }
                }
            }
            $this->app->notFound();
        })
            ->via('POST', 'GET', 'PUT', 'DELETE');
    }

    /**
     * GET or POST /module/controller/action
     * get module, module folder name.
     *
     * @return string
     */
    public function getModuleName()
    {
        return $this->module;
    }

    /**
     * GET or POST /module/controller/action
     * get controller.
     *
     * @return string
     */
    public function getControllerName()
    {
        return $this->controller;
    }

    /**
     * GET or POST /module/controller/action
     * get action.
     *
     * @return string
     */
    public function getActionName()
    {
        return $this->action;
    }
}
