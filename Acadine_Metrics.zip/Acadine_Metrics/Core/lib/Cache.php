<?php

namespace Core\lib;

use Predis;

/**
 * This class is a util class for predis
 * Config redis hosts in config/Config.php.
 */
class Cache
{
    /**
     * @return \Predis\Client
     */
    public static function redis()
    {
        static $client = null;
        if ($client == null) {
            $config = Config::get('redis.config');
            $client = new Predis\Client($config['db']);
        }

        return $client;
    }
}
