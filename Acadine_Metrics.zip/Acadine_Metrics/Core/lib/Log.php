<?php

namespace Core\lib;

/**
 * This class is used to write the log messages.
 */
class Log
{
    /**
     * Get KLogger instance.
     *
     * @return \Katzgrau\KLogger\Logger
     */
    public static function getLogger()
    {
        static $logger = null;
        if ($logger == null) {
            $logConfig = Config::get('log.config');
            $logger = new \Katzgrau\KLogger\Logger($logConfig['file.path'], $logConfig['level']);
        }

        return $logger;
    }
}
