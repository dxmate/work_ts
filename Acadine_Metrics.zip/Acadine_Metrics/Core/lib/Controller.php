<?php

namespace Core\lib;

/**
 * This class is base controller class, use it such as
 * class User extends Controller{}.
 */
class Controller
{
    protected $app;

    /**
     * Display data with template.
     *
     * @param string $template
     * @param array  $data
     * @param string $status
     */
    public function display($template = '', $data = array(), $status = null)
    {
        $template = $template ? $template : App::getInstance()->getActionName().'.html';
        $templateName = App::getInstance()->getModuleName().'/view/'.App::getInstance()->getControllerName().'/'.$template;
        \Slim\Slim::getInstance()->view()->setTemplatesDirectory(APP_PATH.'/Module');
        \Slim\Slim::getInstance()->render($templateName, $data, $status);
    }

    /**
     * Set the display data.
     *
     * @param mixed  $data
     * @param string $value
     */
    public function setData($data, $value = '')
    {
        if (is_array($data)) {
            \Slim\Slim::getInstance()->view->setData($data);
        } else {
            \Slim\Slim::getInstance()->view->setData($data, $value);
        }
    }

    /**
     * Inject Slim app instance.
     *
     * @param \Slim\Slim $app
     */
    public function beforeAction(\Slim\Slim $app, array $params)
    {
        $this->app = $app;
    }
}
