<?php

require APP_PATH.'vendor/autoload.php';
require APP_PATH.'Core/common/Functions.php';
$app = new \Slim\Slim([
    'version' => '0.1',
    'debug' => Core\lib\Config::get('debug'),
    'mode' => Core\lib\Config::get('mode'),
    'cookies.lifetime' => Core\lib\Config::get('cookies.lifetime'),
]);
Core\lib\App::init($app);
$projInitFile = APP_PATH.'/Module/common/Init.php';
if (file_exists($projInitFile)) {
    require $projInitFile;
}
$app->run();
