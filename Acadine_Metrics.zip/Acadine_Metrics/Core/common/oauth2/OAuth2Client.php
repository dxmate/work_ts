<?php
/**
 * OAuth2Client
 *
 * @author fengfei1124@thundersoft.com
 */

namespace Core\common\oauth2;

use Core\common\HttpClient;
use Core\common\oauth2\token\AccessToken;

/**
 * this class is not a complete implementation for oauth2.0
 * just use to get userinfo.
 */
class OAuth2Client
{
    /**
     * @var string
     */
    protected $clientId;

    /**
     * @var string
     */
    protected $clientSecret;

    /**
     * @var string
     */
    protected $redirectUri;

    /**
     * @var string
     */
    protected $accessTokenUrl;

    /**
     * @var string
     */
    protected $resource;

    protected $authorizationCode = 'authorization_code';

    public function __construct(array $options = [])
    {
        foreach ($options as $option => $value) {
            if (property_exists($this, $option)) {
                $this->{$option} = $value;
            }
        }
    }

    public function getAccessToken(string $code)
    {
        $data = [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'code' => $code,
            'grant_type' => $this->authorizationCode,
            'redirect_uri' => $this->redirectUri,
            'resource' => $this->resource,
        ];
        $response = HttpClient::getInstance()->post($this->accessTokenUrl, $data);
        $data = json_decode($response->getBody(), true);
        if (is_null($data)) {
            throw new \Exception('oauth2 server response error access_token data, please contact admin to check logs');
        }
        if (isset($data['error'])) {
            throw new \Exception($data['error_description']);
        }

        return new AccessToken($data);
    }
}
