<?php
/**
 * HttpException
 *
 * @author fengfei1124@thundersoft.com
 */

namespace Core\common;

/**
 * exception for http request error.
 */
class HttpException extends \Exception
{
}
