<?php
/**
 * Singleton
 * 单例类
 * @author fengfei1124@thundersoft.com
 */

namespace Core\common;

/**
 * The super Singleton class.
 */
class Singleton
{
    private static $instances = array();

    /**
     * Get the instance.
     *
     * @return multitype:|unknown
     */
    public static function getInstance()
    {
        $className = get_called_class();
        if (!array_key_exists($className, self::$instances)) {
            self::$instances[$className] = new $className();
        }

        return self::$instances[$className];
    }
}
