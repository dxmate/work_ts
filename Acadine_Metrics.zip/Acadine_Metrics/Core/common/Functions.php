<?php
/**
 * Functions
 * the public functions
 * @author fengfei1124@thundersoft.com
 */

/**
 * Dumps information about a variable.
 *
 * @param mixed  $var
 * @param string $echo
 * @param string $label
 * @param string $strict
 *
 * @return null|string
 */
function dump($var, $echo = true, $label = null, $strict = true)
{
    $label = ($label === null) ? '' : rtrim($label).' ';
    if (!$strict) {
        if (ini_get('html_errors')) {
            $output = print_r($var, true);
            $output = '<pre>'.$label.htmlspecialchars($output, ENT_QUOTES).'</pre>';
        } else {
            $output = $label.print_r($var, true);
        }
    } else {
        ob_start();
        var_dump($var);
        $output = ob_get_clean();
        if (!extension_loaded('xdebug')) {
            $output = preg_replace('/\]\=\>\n(\s+)/m', '] => ', $output);
            $output = '<pre>'.$label.htmlspecialchars($output, ENT_QUOTES).'</pre>';
        }
    }
    if ($echo) {
        echo $output;

        return;
    } else {
        return $output;
    }
}

/**
 * Such as the require_once function but better than require_once.
 *
 * @param string $filename
 *                         文件地址
 *
 * @return bool
 */
function require_cache($filename)
{
    static $importFiles = array();
    if (!isset($importFiles[$filename])) {
        if (file_exists($filename)) {
            require $filename;
            $importFiles[$filename] = true;
        } else {
            $importFiles[$filename] = false;
        }
    }

    return $importFiles[$filename];
}

/**
 * Get value by language.
 *
 * @param string|array $name
 * @param mixed        $value
 *
 * @return mixed
 */
function lang($name = null, $value = null)
{
    static $lang = array();
    if (empty($name)) {
        return $lang;
    }
    if (is_string($name)) {
        $name = strtoupper($name);
        if (is_null($value)) {
            return isset($lang[$name]) ? $lang[$name] : $name;
        } elseif (is_array($value)) {
            $replace = array_keys($value);
            foreach ($replace as &$v) {
                $v = '{$'.$v.'}';
            }

            return str_replace($replace, $value, isset($lang[$name]) ? $lang[$name] : $name);
        }
        $lang[$name] = $value;

        return;
    }
    if (is_array($name)) {
        $lang = array_merge($lang, array_change_key_case($name, CASE_UPPER));
    }

    return;
}

/**
 * This function will return request utc timestamp.
 *
 * @return number
 */
function timestamp()
{
    if (!isset($_SERVER['REQUEST_TIME'])) {
        $_SERVER['REQUEST_TIME'] = time();
    }

    return $_SERVER['REQUEST_TIME'];
}

/**
 * post http request.
 *
 * @param string $url
 * @param mixed  $post_data array or string
 * @param number $timeout,  default 15 secends
 */
function http_post($url, $post_data = null, $timeout = 15)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    if ($post_data) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_HEADER, false);
    $file_contents = curl_exec($ch);
    curl_close($ch);

    return $file_contents;
}

/**
 * This function is used to create unique string id.
 *
 * @return string
 */
function guid()
{
    if (function_exists('com_create_guid')) {
        return com_create_guid();
    } else {
        mt_srand((double) microtime() * 10000); //optional for php 4.2.0 and up.
        $charid = strtolower(md5(uniqid(rand(), true)));
        $uuid = substr($charid, 0, 8).substr($charid, 8, 4).substr($charid, 12, 4).substr($charid, 16, 4).substr($charid, 20, 12);

        return $uuid;
    }
}
