<?php
/**
 * HttpResponse
 * the information return by HTTP request
 * @author fengfei1124@thundersoft.com
 */

namespace Core\common;

/**
 * http response.
 */
class HttpResponse
{
    /**
     * http status.
     *
     * @var int
     */
    public $status;

    /**
     * http body.
     *
     * @var string
     */
    public $body;

    /**
     * http response headers.
     *
     * @var array
     */
    public $headers;

    public function __construct($body, $status = 200, $headers = [])
    {
        $this->body = $body;
        $this->status = $status;
        $this->headers = $headers;
    }

    /**
     * http body content.
     *
     * @return string
     */
    public function getBody()
    {
        return $this->body;
    }

    /**
     * http status.
     *
     * @return number
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * http headers.
     *
     * @return array
     */
    public function getHeaders()
    {
        return $this->headers;
    }

    /**
     * http header.
     *
     * @param string $name
     *
     * @return string|null
     */
    public function getHeader($name)
    {
        if (array_key_exists($name, $this->headers)) {
            return $this->headers[$name];
        }

        return;
    }
}
