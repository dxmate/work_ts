<?php
/**
 * HttpClient
 * achieve http link
 * @author fengfei1124@thundersoft.com
 */

namespace Core\common;

use Core\lib\Log;
use Module\common\config\AdapterParamKeys;

/**
 * simple httpclient.
 */
class HttpClient
{
    const METHOD_GET = 'GET';

    const METHOD_POST = 'POST';

    private static $mockResponses = [];

    private $curlHandle;

    private $timeout = 300;

    private $headers = [];

    private $response;

    public function __construct()
    {
        $this->curlHandle = curl_init();
        curl_setopt($this->curlHandle, CURLOPT_RETURNTRANSFER, 1);
    }

    /**
     * @return HttpClient
     */
    public static function getInstance()
    {
        return new self();
    }

    /**
     * @param array $morkResponses
     *                             ['url'=>HttpResponse]
     */
    public static function mock(array $mockResponses)
    {
        self::$mockResponses = array_merge(self::$mockResponses, $mockResponses);
    }

    /**
     * set timeout.
     *
     * @param int $secend
     *
     * @return HttpClient
     */
    public function timeout(int $secend)
    {
        $this->timeout = $secend;

        return $this;
    }

    /**
     * set http headers.
     *
     * @param array $headers
     *                       http headers ['header-key'=>'header-value']
     *
     * @return \Core\common\HttpClient
     */
    public function headers(array $headers)
    {
        $this->headers = array_merge($this->headers, $headers);

        return $this;
    }

    /**
     * curl_setopt.
     *
     * @param array $opts
     *
     * @return \Core\common\HttpClient
     */
    public function setopts(array $opts)
    {
        foreach ($opts as $optKey => $optValue) {
            curl_setopt($this->curlHandle, $optKey, $optValue);
        }

        return $this;
    }

    /**
     * http post request.
     *
     * @param string $url
     * @param mixed  $params
     *                       string or array
     *
     * @return \Core\common\HttpResponse
     *
     * @throws HttpException
     */
    public function post($url, $params = [])
    {
        return $this->request($url, self::METHOD_POST, $params);
    }

    /**
     * http get request.
     *
     * @param string $url
     * @param array  $params
     *
     * @return \Core\common\HttpResponse
     *
     * @throws HttpException
     */
    public function get($url, $params = [])
    {
        return $this->request($url, self::METHOD_GET, $params);
    }

    /**
     * post http request.
     *
     * @param string $url
     * @param mixed  $params
     *                       array or string
     *
     * @return \Core\common\HttpResponse
     *
     * @throws HttpException
     */
    public function request($url, $method = self::METHOD_GET, $params = [])
    {
        $params[AdapterParamKeys::API_KEY] = $_ENV['API_KEY'];
        $params[AdapterParamKeys::TS] = $_ENV['TS'];
        $params[AdapterParamKeys::HMAC] = $_ENV['HMAC'];
        Log::getLogger()->debug('HttpClient->request->start', [
            'url' => $url,
            'headers' => $this->headers,
            'params' => $params,
            'timeout' => $this->timeout,
        ]);
        if (array_key_exists($url, self::$mockResponses)) {
            return self::$mockResponses[$url];
        }
        if (false == $this->curlHandle) {
            Log::getLogger()->error('curl init failed');
            throw new HttpException('curl init failed', -1);
        }
        if ($method == self::METHOD_POST) {
            curl_setopt($this->curlHandle, CURLOPT_POST, 1);
            curl_setopt($this->curlHandle, CURLOPT_POSTFIELDS, $params);
        } elseif ($method == self::METHOD_GET) {
            $query = http_build_query($params);
            if (strlen($query) > 0) {
                $url .= '?'.$query;
            }
        }
        // add headers
        if (count($this->headers)) {
            $headers = [];
            foreach ($this->headers as $key => $value) {
                $headers[] = $key.': '.$value;
            }
            curl_setopt($this->curlHandle, CURLOPT_HTTPHEADER, $headers);
        }
        curl_setopt($this->curlHandle, CURLOPT_URL, $url);
        curl_setopt($this->curlHandle, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($this->curlHandle, CURLOPT_CONNECTTIMEOUT, $this->timeout);
        curl_setopt($this->curlHandle, CURLOPT_HEADER, 1);
        $contents = curl_exec($this->curlHandle);
        $info = curl_getinfo($this->curlHandle);
        $errno = curl_errno($this->curlHandle);
        $headerSize = curl_getinfo($this->curlHandle, CURLINFO_HEADER_SIZE);
        $httpCode = curl_getinfo($this->curlHandle, CURLINFO_HTTP_CODE);
        curl_close($this->curlHandle);
        if ($errno != 0) {
            throw new HttpException('', $errno);
        }
        $headerContent = substr($contents, 0, $headerSize);
        $resHeaders = [];
        $tempHeaders = explode("\r\n", $headerContent);
        foreach ($tempHeaders as $tempHeader) {
            $arr = explode(':', $tempHeader);
            if (count($arr) == 2) {
                $resHeaders[$arr[0]] = trim($arr[1]);
            }
        }
        $body = trim(substr($contents, $headerSize));
        Log::getLogger()->debug('HttpClient->request->end', [
            'url' => $url,
            'params' => $params,
            'body' => $body,
            'headers' => $resHeaders,
        ]);
        $this->response = new HttpResponse($body, $httpCode, $resHeaders);

        return $this->response;
    }
}
