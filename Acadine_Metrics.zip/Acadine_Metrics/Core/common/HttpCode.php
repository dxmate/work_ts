<?php
/**
 * HttpCode
 * HTTP type code
 * @author fengfei1124@thundersoft.com
 */

namespace Core\common;

class HttpCode
{
    const HTTP_SUCCESS = 200;

    const HTTP_NOT_FOUND = 404;

    const HTTP_INNER_ERROR = 500;
}
