var gulp = require("gulp"),
    mainBowerFiles = require("gulp-main-bower-files"),
    uglify = require("gulp-uglify"),
    minifyCss = require('gulp-minify-css'),
    clean = require('gulp-clean'),
    sourcemaps = require('gulp-sourcemaps'),
    less = require('gulp-less'),
    replace = require('gulp-replace'),
    concat = require('gulp-concat');

    distbasePath = "public/pages",
    assetsbasePath = distbasePath + "/assets",

    srcHtml = "pages/src/**/*.html",
    srcStatic = "pages/src/static/*",
    srcJs = "pages/src/js/**/*.js",
    srcLibsJs = 'pages/src/libsJs/**/*.js',
    srcLibsCss = 'pages/src/libsCss/**/*',
    srcLess = "pages/src/less/*.less",
    srcModulesLess = "pages/src/less/modules/**/*.less",
    tasks = [
             "uglify-js-libs",
             "uglify-css-libs",
             "uglify-js-src",
             "uglify-css-src",
             "uglify-main-css-modules",
             "copy-html-src",
             'copy-libs-js-src',
             'copy-libs-css-src',
             'copy-static-file'
         ];
/*js version number*/
var JS_VERSION_NUMBER = 1;

/**
 * clear libraries
 */
gulp.task("lib-clean", function(){
    return gulp.src(assetsbasePath + "/libs", {read: false})
        .pipe(clean());
});

/**
 * clear static file
 */
gulp.task("static-clean", function(){
    return gulp.src(assetsbasePath + "/static", {read: false})
        .pipe(clean());
});

/**
 * clear dev css
 */
gulp.task("css-clean", function(){
    return gulp.src(assetsbasePath + "/css", {read: false})
        .pipe(clean());
});

/**
 * clear dev js
 */
gulp.task("js-clean", function(){
    return gulp.src(assetsbasePath + "/js", {read: false})
        .pipe(clean());
});

/**
 * clear dev source map
 */
gulp.task("map-clean", function(){
    return gulp.src(assetsbasePath + "/maps", {read: false})
        .pipe(clean());
});

/**
 * clear dev html
 */
gulp.task("html-clean", function(){
    return gulp.src(distbasePath + "/*.html", {read: false})
        .pipe(clean());
});

/**
 * pick up the library files
 */
gulp.task("pickup-bower-files", ["lib-clean"], function(){
    var conf = {
        overrides: {
            AdminLTE: {
                main: [
                    "./dist/js/app.min.js",
                    "./dist/css/**/*.min.*",
                    "./bootstrap/css/*.min.*",
                    "./bootstrap/fonts/**/*",
                    "./bootstrap/js/*.min.*"
                ]
            }
        }
    };
    return gulp.src("./bower.json")
        .pipe(mainBowerFiles(conf))
        .pipe(gulp.dest(assetsbasePath + "/libs"));
});

/**
 * pick up the admin-lte-plugins
 */
gulp.task("pickup-admin-lte-plugins" , ["lib-clean"], function() {
    var srcPlugins = "./bower_components/AdminLTE/plugins/**/*";

    return gulp.src(srcPlugins)
        .pipe(gulp.dest(assetsbasePath + "/libs/AdminLTE/plugins"));
});

/**
 * uglify libraries js
 */
gulp.task("uglify-js-libs", ["pickup-bower-files", "pickup-admin-lte-plugins"], function() {

    return gulp.src([assetsbasePath + "/libs/**/*.js", "!" + assetsbasePath + "/libs/AdminLTE/plugins/**/*.js"])
        .pipe(uglify())
        .pipe(gulp.dest(assetsbasePath + "/libs"));
});

/**
 * uglify libraries css
 */
gulp.task("uglify-css-libs", ["pickup-bower-files", "pickup-admin-lte-plugins"], function () {

    return gulp.src([assetsbasePath + "/libs/**/*.css", "!" + assetsbasePath + "/libs/AdminLTE/plugins/**/*.css"])
        .pipe(minifyCss())
        .pipe(gulp.dest(assetsbasePath + "/libs"));
});

/**
 * uglify js file from src
 */
gulp.task("uglify-js-src", ["js-clean", "map-clean"], function(){
    return gulp.src(srcJs)
        .pipe(replace('var JS_VERSION;', 'var JS_VERSION = ' + JS_VERSION_NUMBER + ';'))
        .pipe(sourcemaps.init())
        .pipe(uglify().on('error', function(e){
            console.log(e);
         }))
        .pipe(sourcemaps.write('./maps/'))
        .pipe(gulp.dest(assetsbasePath + '/js/'));
});

/**
 * uglify css file from src
 */
gulp.task("uglify-css-src", ["css-clean"], function(){
  return gulp.src([srcLess, '!' + srcModulesLess, '!pages/src/less/main.less'])
        .pipe(less())
        .pipe(minifyCss({keepBreaks: true}))
        .pipe(gulp.dest(assetsbasePath + '/css/'));
});

/**
 * concat modules css file from less-main-modules
 */
gulp.task("uglify-main-css-modules", ["css-clean"], function(){
    return gulp.src([srcModulesLess, 'pages/src/less/main.less'])
        .pipe(less())
        .pipe(concat('main.css'))
        .pipe(minifyCss({keepBreaks: true}))
        .pipe(gulp.dest(assetsbasePath + '/css/'));
});

/**
 * copy html
 */
gulp.task("copy-html-src", function(){
    return gulp.src(srcHtml)
        .pipe(gulp.dest(distbasePath));
});

/**
 * copy libsJs
 */
gulp.task("copy-libs-js-src", ['uglify-js-libs'], function(){
    return gulp.src(srcLibsJs)
        .pipe(gulp.dest(assetsbasePath + '/libs/AdminLTE/plugins/'));
});

/**
 * copy libsCss
 */
gulp.task("copy-libs-css-src", ['uglify-css-libs'], function(){
    return gulp.src(srcLibsCss)
        .pipe(gulp.dest(assetsbasePath + '/libs/AdminLTE/plugins/'));
});

/**
 * copy static file
 */
gulp.task("copy-static-file", ["static-clean"], function(){
    return gulp.src(srcStatic)
        .pipe(gulp.dest(assetsbasePath + "/static/"));
});

gulp.task("default", tasks, function() {
    gulp.watch([srcLess, '!' + srcModulesLess, '!pages/src/less/main.less'], ['uglify-css-src', 'uglify-main-css-modules']);
    gulp.watch([srcModulesLess, 'pages/src/less/main.less'], ['uglify-css-src', 'uglify-main-css-modules']);
    gulp.watch(srcHtml, ['copy-html-src']);
    gulp.watch(srcStatic, ['copy-static-file']);
    gulp.watch(srcJs, ['uglify-js-src']);
});
