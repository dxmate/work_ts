/**
 * welcome page
 * @since 2016-1-22 11:28
 */
require(['common'], function(common) {
    'use strict';
    require(['app/welcomeApp']);
});
