/**
 * mainApp js
 * @since 2016-1-21 11:00
 */
define(['jquery', 'modules/common/menu', 'modules/common/header'], function($, menu, header) {
    'use strict';
    var commonPath = 'modules/common';

    var mainApp = {};

    /*首次加载header和left menu*/
    $(function() {
        $('.main-header').load(commonPath + '/header.html', function(responseTxt, statusTxt) {
            if (statusTxt == 'success') {
                header.init();
            }
        });
        $('.main-sidebar').load(commonPath + '/menu.html', function(responseTxt, statusTxt) {
            if (statusTxt == 'success') {
                menu.initMenuList();
            }
        });
    });

    /*切换content接口*/
    mainApp.switchContent = function(target) {
        $('.content-wrapper').load(target[0], function(responseTxt, statusTxt) {
            if (statusTxt == 'success') {
                require([target[1]], function(currentModulesJs) {
                    currentModulesJs.execute();
                });
            }
        });
    };

    return mainApp;
});