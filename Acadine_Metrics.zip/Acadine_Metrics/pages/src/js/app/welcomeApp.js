/**
 * welcomeApp js
 * @since 2016-1-21 11:00
 */
define(['jquery', 'tools/http'], function($,http) {
    'use strict';
    var welcomeApp = {};

    $(function() {
        initLoginClick();
    });

    /*初始化登陆链接*/
    function initLoginClick() {
        $('#login-btn').click(function() {
            window.location.href = http.httpUrl.login;
        });
    }

    return welcomeApp;
});