/**
 * reqireJs 配置文件
 * @since 2016-1-22 11:28
 */
'use strict';
var JS_VERSION;
var ACADINE_DASHBOARD_STATIC_URL = './assets/';
require.config({
    baseUrl: ACADINE_DASHBOARD_STATIC_URL + 'js',
    urlArgs: 'v=' + JS_VERSION,
    shim: {
        'bootstrap': {
            'deps': ['jquery']
        },
        'AdminLTEApp': {
            'deps': ['bootstrap']
        },
        'daterangepicker': {
            'deps': ['moment']
        },
        'select2': {
            'deps': ['bootstrap']
        }
    },
    paths: {
        'AdminLTEApp': '../libs/AdminLTE/dist/js/app.min',
        'daterangepicker': '../libs/AdminLTE/plugins/daterangepicker/daterangepicker',
        'select2': '../libs/AdminLTE/plugins/select2/select2.min',
        'chart': '../libs/AdminLTE/plugins/chartjs/Chart.min',
        'moment': '../libs/AdminLTE/plugins/moment/moment.min',
        'jquery': '../libs/AdminLTE/plugins/jQuery/jQuery-2.1.4.min',
        'bootstrap': '../libs/AdminLTE/bootstrap/js/bootstrap.min',
        'util': 'tools/util',
        'date': 'tools/date',
        'validate': 'tools/validate',
        'pluginsConfig': 'tools/pluginsConfig',
        'app': 'app'
    },
    waitSeconds: 0
});
