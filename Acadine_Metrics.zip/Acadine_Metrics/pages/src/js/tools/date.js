/**
 * date util
 * @since 2016-1-21 14:52
 */
define(['jquery', 'util'], function($, util) {
    'use strict';
    var date = {};

    /*获取daterangepicker的时间*/
    date.getDate = function(date, isStartDate) {
        var dateArr = date.split('-');

        if (isStartDate) {
            return util.trimAll(dateArr[0] + '-' + dateArr[1] + '-' + dateArr[2]);
        } else {
            return util.trimAll(dateArr[3] + '-' + dateArr[4] + '-' + dateArr[5]);
        }
    };

    /*获取N天后的日期*/
    date.getAfterDate = function(AddDayCount) {
        var mDate = new Date();
        mDate.setDate(mDate.getDate() + AddDayCount);
        var year = mDate.getFullYear();
        var month = (mDate.getMonth() + 1) < 10 ? "0" + (mDate.getMonth() + 1) : (mDate.getMonth() + 1);
        var day = mDate.getDate() < 10 ? "0" + mDate.getDate() : mDate.getDate();
        return year + "-" + month + "-" + day;
    };

    /*获取当前日期*/
    date.getCurrentDate = function() {
        var mDate = new Date();
        var year = mDate.getFullYear();
        var month = (mDate.getMonth() + 1) < 10 ? "0" + (mDate.getMonth() + 1) : (mDate.getMonth() + 1);
        var day = mDate.getDate() < 10 ? "0" + mDate.getDate() : mDate.getDate();
        return year + "-" + month + "-" + day;
    };

    /*判断当前时间是一年的第几周*/
    date.weekOfYear = function(sdate) {
        var d = new Date(sdate);
        var myYear = d.getFullYear();
        var firstDate = new Date(myYear + "-01-01");
        var dayofyear = 0;
        for (var i = 0; i < d.getMonth(); i++) {
            switch (i) {
                case 0:
                case 2:
                case 4:
                case 6:
                case 7:
                case 9:
                    dayofyear += 31;
                    break;
                case 1:
                    if (isLeapYear(d)) {
                        dayofyear += 29;
                    } else {
                        dayofyear += 28;
                    }
                    break;
                case 3:
                case 5:
                case 8:
                case 10:
                    dayofyear += 30;
                    break;
            }
        }
        dayofyear += d.getDate() + 1;
        var week = firstDate.getDay();
        var dayNum = dayofyear - (7 - week);
        var weekNum = 1;
        weekNum = weekNum + (dayNum / 7);
        if (dayNum % 7 != 0)
            weekNum = weekNum + 1;
        return parseInt(weekNum);
    };

    function isLeapYear(date) {
        return (0 == date.getFullYear() % 4 && ((date.getFullYear() % 100 != 0) || (date.getFullYear() % 400 == 0)));
    }

    return date;
});