/**
 * validate
 * @since 2016-1-21 14:52
 */
define(['jquery', 'util'], function($, util) {
    'use strict';
    var validate = {};

    /*验证日期的基本格式*/
    validate.validateDate = function(date, formDom) {
        var dateArr = date.split('-');
        if (dateArr.length != 6) {
            if (formDom) {
                $(formDom).addClass('has-error');
                $(formDom).find('.error-label').removeClass('dom-hide');
            }
            return false;
        } else {
            var exp = new RegExp('^[1-2]{1}([0-9]{3})-([0-1]{1})([0-9]{1})-(([0-2]){1}([0-9]{1})|([3]{1}[0-1]{1}))$');
            var startDate = util.trimAll(dateArr[0] + '-' + dateArr[1] + '-' + dateArr[2]);
            var endDate = util.trimAll(dateArr[3] + '-' + dateArr[4] + '-' + dateArr[5]);

            if (exp.test(startDate) && exp.test(endDate)) {
                if (formDom) {
                    $(formDom).removeClass('has-error');
                    $(formDom).find('.error-label').addClass('dom-hide');
                }
                return true;
            } else {
                if (formDom) {
                    $(formDom).addClass('has-error');
                    $(formDom).find('.error-label').removeClass('dom-hide');
                }
                return false;
            }
        }
    };

    return validate;
});