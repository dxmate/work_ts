/**
 * admin lte all plugins config
 * @since 2016-1-21 14:52
 */
define(['jquery'], function($) {
    'use strict';
    var pluginsConfig = {};

    /*全局线性表配置*/
    pluginsConfig.lineChartOptions = {
        datasetFill: false,
        pointDot: true,
        scaleShowGridLines: true,
        responsive: true,
        bezierCurve: false
    };

    /*风格１的线性图表*/
    pluginsConfig.lineDataStyle1 = function() {
        this.label = "";
        this.fillColor = "rgba(210, 214, 222, 1)";
        this.strokeColor = "rgba(210, 214, 222, 1)";
        this.pointColor = "rgba(210, 214, 222, 1)";
        this.pointStrokeColor = "#c1c7d1";
        this.pointHighlightFill = "#fff";
        this.pointHighlightStroke = "rgba(220,220,220,1)";
        this.data = [];
    };

    /*风格２的线性图表*/
    pluginsConfig.lineDataStyle2 = function() {
        this.label = "";
        this.fillColor = "rgba(60,141,188,0.9)";
        this.strokeColor = "rgba(60,141,188,0.8)";
        this.pointColor = "#3b8bba";
        this.pointStrokeColor = "rgba(60,141,188,1)";
        this.pointHighlightFill = "#fff";
        this.pointHighlightStroke = "rgba(60,141,188,1)";
        this.data = [];
    };

    return pluginsConfig;
});
