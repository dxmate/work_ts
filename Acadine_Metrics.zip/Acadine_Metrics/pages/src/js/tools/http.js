/**
 * http util
 * @since 2016-1-21 14:52
 */
define(['jquery'], function($) {
    'use strict';
    var http = {};

    var version = '/v1';
    var httpTimeout = 1000 * 60 * 5;

    //401. 302处理的对象
    var requestDo = {
        rq302: function(data) {
            window.location.href = data.info;
        },
        rq401: function(data) {
            window.location.href = '/pages/welcome.html';
        }
    };

    http.httpUrl = {
        getMenu: '/menu/get',
        getAccountusageValidatedusersdaily: '/accountusage/validatedusersdaily',
        getAccountusageValidatedusersTotal: '/accountusage/validateduserstotal',
        getAccountusageActiveusersdaily: '/accountusage/activeusersdaily',
        getAccountusageActiveusersweekly: '/accountusage/activeusersweekly',
        getAccountusageOptions: '/accountusage/options',
        getAntitheftusageEnabledsum: '/antitheftusage/enabledsum',
        getAntitheftusageLockdaily: '/antitheftusage/lockdaily',
        getAntitheftusageWipedaily: '/antitheftusage/wipedaily',
        getAntitheftusageDeviceoptions: '/antitheftusage/deviceoptions',
        getTelemetryFtuoptions: '/telemetry/ftuoptions',
        getTelemetryFtusum: '/telemetry/ftusum',
        getTelemetryFtudaily: '/telemetry/ftudaily',
        login: '/v1/login/office365/acadine',
        logOut: '/user/logout',
        getUserInfo: '/user/info',
        getVersion: version
    };

    /*显示加载框*/
    function showLoading(targetDiv) {
        $(targetDiv).find('.loading').removeClass('dom-hide');
    }

    /*隐藏加载框*/
    function hideLoading(targetDiv) {
        $(targetDiv).find('.loading').addClass('dom-hide');
    }

    /*显示弹出框*/
    function showAlert(msg) {
        $('#modal-text').text(msg);
        $('#modal').modal('show');
    }

    /*封装的http请求*/
    http.request = function(type, url, paramObj, callback, targetDiv) {
        if (targetDiv) {
            showLoading(targetDiv);
        }
        //发出请求
        $.ajax({
            type: type,
            url:  version + url,
            dataType: 'json',
            timeout: httpTimeout,
            data: paramObj,
            success: function(data) {
                if (data.errno === 0) {
                    if (targetDiv) {
                        hideLoading(targetDiv);
                    }
                    callback(data.info, version + url);
                }
            },
            error: function(err) {
                if (targetDiv) {
                    hideLoading(targetDiv);
                }
                //对401, 302等的处理
                if (requestDo['rq' + JSON.parse(err.responseText).status]) {
                    requestDo['rq' + JSON.parse(err.responseText).status](JSON.parse(err.responseText));
                    return;
                }
                if (JSON.parse(err.responseText).errno) {
                    showAlert(JSON.parse(err.responseText).msg);
                }
            }
        });
    };

    return http;
});