/**
 * utils
 * @since 2016-1-21 14:52
 */
define(['jquery', 'select2'], function($, select2) {
    'use strict';
    var util = {};

    /*设定reset按钮的点击逻辑*/
    util.initResetClick = function(index) {
        $('.select-' + index).each(function() {
            $(this).select2('val', '');
        });
        $('.reservation-' + index).val('');
    };

    /*去掉所有空白*/
    util.trimAll = function(str) {
        return str.replace(/\s/g, '');
    };

    return util;
});
