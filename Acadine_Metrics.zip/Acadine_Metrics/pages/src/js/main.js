/**
 * index页面入口
 * @since 2016-1-22 11:28
 */
require(['common'], function(common) {
    'use strict';
    var commonPath = 'modules/common';
    require(['AdminLTEApp']);
    require(['app/mainApp']);
    require([commonPath + '/menu']);
});