/**
 *    Sfp Activation 页 js
 *    @since 2016-01-21 11:00
 */
define(['jquery', 'daterangepicker', 'chart', 'select2', 'util', 'tools/http', 'pluginsConfig', 'validate', 'date'], function($,
    daterangepicker, chart, select2, util, http, pluginsConfig, validate, date) {
    'use strict';
    var sfpActivation = {};

    var requestUrls = [http.httpUrl.getTelemetryFtudaily, http.httpUrl.getTelemetryFtusum];

    var lineChartData = {
        labels: [],
        datasets: []
    };

    sfpActivation.execute = function() {
        initTimePicker();
        initSelect();
        initClick();
    };

    /*初始化点击事件*/
    function initClick() {
        /*设置csv文件下载路径*/
        $('#csv-link').bind('click', function() {
            var dateVal = $($('.reservation-1')[0]).val();
            if (validate.validateDate(dateVal, '#form-timepicker')) {
                var startDate = date.getDate(dateVal, true);
                var endDate = date.getDate(dateVal, false);
                var osParam = $($('.select-1')[0]).select2('val'),
                deviceParam = $($('.select-1')[1]).select2('val'),
                operatorParam = $($('.select-1')[2]).select2('val'),
                countryParam = $($('.select-1')[3]).select2('val'),
                chipsetParam = $($('.select-1')[4]).select2('val');

                var url = http.httpUrl.getVersion + requestUrls[0] + '?startDate=' + startDate + '&endDate=' + endDate + '&format=csv';

                if (osParam) {
                    url = url + '&os=' + osParam;
                }
                if (deviceParam) {
                    url = url + '&device=' + deviceParam;
                }
                if (operatorParam) {
                    url = url + '&operator=' + operatorParam;
                }
                if (countryParam) {
                    url = url + '&country=' + countryParam;
                }
                if (chipsetParam) {
                    url = url + '&chipset=' + chipsetParam;
                }
                setDownloadCsvLink(url);
            }
        });

        //reset按钮点击事件
        $('.reset-btn').each(function(index) {
            $(this).click(function() {
                util.initResetClick(index + 1);
            });
        });
        //commit按钮点击事件
        $('.commit-btn').each(function(index) {
            $(this).click(function() {
                getCurrentDate(index);
            });
        });
    }

    /*得到当前时间*/
    function getCurrentDate(index) {
        var dateVal = $($('.reservation-' + (index + 1))[0]).val();
        if (validate.validateDate(dateVal, $('.form-timepicker')[index])) {
            var startDate = date.getDate(dateVal, true);
            var endDate = date.getDate(dateVal, false);
            initCommitClick(index, startDate, endDate);
        }
    }

    /*初始化Commit按钮点击事件*/
    function initCommitClick(index, startDate, endDate) {
        var osParam = $($('.select-' + (index + 1))[0]).select2('val'),
            deviceParam = $($('.select-' + (index + 1))[1]).select2('val'),
            operatorParam = $($('.select-' + (index + 1))[2]).select2('val'),
            countryParam = $($('.select-' + (index + 1))[3]).select2('val'),
            chipsetParam = $($('.select-' + (index + 1))[4]).select2('val');

        var url = requestUrls[index] + '?startDate=' + startDate + '&endDate=' + endDate;

        if (osParam) {
            url = url + '&os=' + osParam;
        }
        if (deviceParam) {
            url = url + '&device=' + deviceParam;
        }
        if (operatorParam) {
            url = url + '&operator=' + operatorParam;
        }
        if (countryParam) {
            url = url + '&country=' + countryParam;
        }
        if (chipsetParam) {
            url = url + '&chipset=' + chipsetParam;
        }

        http.request('get', url, null, function(data, reqUrl) {
            switch (index) {
                case 0:
                    var dailyList = data.data;
                    var labelsArr = [];
                    var datasetsArr = [];
                    datasetsArr[0] = new pluginsConfig.lineDataStyle2();
                    datasetsArr[0].label = 'daily count';
                    for (var i = 0; i < dailyList.length; i++) {
                        labelsArr[i] = dailyList[i].date;
                        datasetsArr[0].data[i] = dailyList[i].count;
                    }
                    lineChartData.labels = labelsArr;
                    lineChartData.datasets = datasetsArr;
                    //初始化图表
                    initLineChart();
                    break;
                case 1:
                    $('#total-line').removeClass('dom-hide');
                    $('#total-label').html(data.count);
                    break;
                default:
                    break;
            }
        }, $('.box-body')[index]);
    }

    /*生成csv文件下载链接*/
    function setDownloadCsvLink(url) {
        window.location.href = url;
    }

    /*初始化时间选择器*/
    function initTimePicker() {
        $('.reservation-1').daterangepicker({
            format: 'YYYY-MM-DD'
        });
        $('.reservation-2').daterangepicker({
            format: 'YYYY-MM-DD'
        });
        setDefaultDate();
    }

    /*设置一个默认显示的时间*/
    function setDefaultDate() {
        var defaultDate = date.getAfterDate(-90) + '-' + date.getCurrentDate(-1);
        $($('.reservation-1')[0]).val(defaultDate);
        $($('.reservation-2')[0]).val(defaultDate);
    }

    /*初始化下拉框*/
    function initSelect() {
        //获取options
        http.request('get', http.httpUrl.getTelemetryFtuoptions, null, function(data) {
            var osHtml = '',
                deviceHtml = '',
                operatorHtml = '',
                countryHtml = '',
                chipsetHtml = '';
            for (var osIndex = 0, osLength = data.os.length; osIndex < osLength; osIndex++) {
                var option = (data.os)[osIndex].trim() == '' ? 'empty' : (data.os)[osIndex];
                osHtml += '<option>' + option + '</option>';
            }
            for (var deviceIndex = 0, deviceLength = data.device.length; deviceIndex < deviceLength; deviceIndex++) {
                var option = (data.device)[deviceIndex].trim() == '' ? 'empty' : (data.device)[deviceIndex];
                deviceHtml += '<option>' + option + '</option>';
            }
            for (var operatorIndex = 0, operatorLength = data.operator.length; operatorIndex < operatorLength; operatorIndex++) {
                var option = (data.operator)[operatorIndex].trim() == '' ? 'empty' : (data.operator)[operatorIndex];
                operatorHtml += '<option>' + option + '</option>';
            }
            for (var countryIndex = 0, countryLength = data.country.length; countryIndex < countryLength; countryIndex++) {
                var option = (data.country)[countryIndex].trim() == '' ? 'empty' : (data.country)[countryIndex];
                countryHtml += '<option>' + option + '</option>';
            }
            for (var chipsetIndex = 0, chipsetLength = data.chipset.length; chipsetIndex < chipsetLength; chipsetIndex++) {
                var option = (data.chipset)[chipsetIndex].trim() == '' ? 'empty' : (data.chipset)[chipsetIndex];
                chipsetHtml += '<option>' + option + '</option>';
            }
            $($('.select-1')[0]).html(osHtml);
            $($('.select-2')[0]).html(osHtml);
            $($('.select-1')[1]).html(deviceHtml);
            $($('.select-2')[1]).html(deviceHtml);
            $($('.select-1')[2]).html(operatorHtml);
            $($('.select-2')[2]).html(operatorHtml);
            $($('.select-1')[3]).html(countryHtml);
            $($('.select-2')[3]).html(countryHtml);
            $($('.select-1')[4]).html(chipsetHtml);
            $($('.select-2')[4]).html(chipsetHtml);
            $('.select2').select2();
        }, $('.box-body'));
    }

    /*初始化线性图表*/
    function initLineChart() {
        $('#chart-line').removeClass('dom-hide');
        //删除canvas节点，避免重复绘制
        $('#lineChart').remove();
        $('#lineChartParent').append('<canvas class="line-chart" id="lineChart"></canvas>');
        var lineChartCanvas = $("#lineChart").get(0).getContext("2d");
        var lineChart = new Chart(lineChartCanvas);
        lineChart.Line(lineChartData, pluginsConfig.lineChartOptions);
        var lengndTemple = '';
        for (var i = 0; i < lineChartData.datasets.length; i++) {
            lengndTemple += '<li>';
            lengndTemple += '<span style="background-color: ' + lineChartData.datasets[i].strokeColor + ';"></span> ' + lineChartData.datasets[i].label;
            lengndTemple += '</li>';
        }
        $('#lineChartTemple').find('.list-inline').html(lengndTemple);
    }

    return sfpActivation;
});
