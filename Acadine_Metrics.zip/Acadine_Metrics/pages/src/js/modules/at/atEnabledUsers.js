/**
 * at-enabled-users js
 * @since 2016-1-21 11:00
 */
define(['jquery', 'daterangepicker', 'chart', 'select2', 'util', 'tools/http', 'validate', 'date', 'pluginsConfig'],
    function($, daterangepicker, chart, select2, util, http, validate, date, pluginsConfig) {
        'use strict';
        var atEnabledUsers = {};

        var lineChartData = {
            labels: [],
            datasets: []
        };

        var deviceLineCharData = {
            labels: [],
            datasets: []
        };

        atEnabledUsers.execute = function() {
            initTimePicker();
            initSelect();
            initClick();
        };

        /*初始化点击时间*/
        function initClick() {
            /*设置csv文件下载路径*/
            $('#csv-link').bind('click', function() {
                var dateVal = $($('.reservation-1')[0]).val();
                if (validate.validateDate(dateVal, '#form-timepicker')) {
                    var startDate = date.getDate(dateVal, true);
                    var endDate = date.getDate(dateVal, false);
                    var deviceVal = $('.select2').select2('val');
                    var requestUrl = http.httpUrl.getVersion + http.httpUrl.getAntitheftusageEnabledsum +
                            '?startDate=' + startDate +
                            '&endDate=' + endDate +
                            '&format=csv';
                    if (deviceVal) {
                        requestUrl = requestUrl + '&device=' + deviceVal;
                    }
                    setDownloadCsvLink(requestUrl);
                }
            });

            //reset按钮点击事件
            $('.reset-btn').each(function(index) {
                $(this).click(function() {
                    util.initResetClick(index + 1);
                });
            });
            //commit按钮点击事件
            $('.commit-btn').click(function() {
                initCommitClick();
            });
        }

        /*初始化commit按钮点击事件*/
        function initCommitClick() {
            var dateVal = $($('.reservation-1')[0]).val();
            if (validate.validateDate(dateVal, '#form-timepicker')) {
                var startDate = date.getDate(dateVal, true);
                var endDate = date.getDate(dateVal, false);
                var deviceVal = $('.select2').select2('val');
                var requestUrl = http.httpUrl.getAntitheftusageEnabledsum +
                        '?startDate=' + startDate +
                        '&endDate=' + endDate;

                if (deviceVal) {
                    requestUrl = requestUrl + '&device=' + deviceVal;
                }
                //请求图表数据
                http.request('get', requestUrl, null, function(data, reqUrl) {
                    var deviceList = data.data;
                    var labelsArr = [];
                    var dataSetsArr = [];
                    var deviceSetsArr = [];
                    dataSetsArr[0] = new pluginsConfig.lineDataStyle2();
                    dataSetsArr[0].label = 'user count';
                    deviceSetsArr[0] = new pluginsConfig.lineDataStyle2();
                    deviceSetsArr[0].label = 'device count';
                    for (var i = 0; i < deviceList.length; i++) {
                        labelsArr[i] = deviceList[i].date;
                        dataSetsArr[0].data[i] = deviceList[i].usercount;
                        deviceSetsArr[0].data[i] = deviceList[i].devicecount;
                    }
                    lineChartData.labels = labelsArr;
                    lineChartData.datasets = dataSetsArr;
                    deviceLineCharData.labels = labelsArr;
                    deviceLineCharData.datasets = deviceSetsArr;
                    //初始化图表
                    initLineChart();
                }, '.box-body');
            }
        }

        /*生成csv文件下载链接*/
        function setDownloadCsvLink(url) {
            window.location.href = url;
        }

        /*初始化时间选择器*/
        function initTimePicker() {
            $('.reservation-1').daterangepicker({
                format: 'YYYY-MM-DD'
            });
            setDefaultDate();
        }

        /*初始化下拉框*/
        function initSelect() {
            //获取device options
            http.request('get', http.httpUrl.getAntitheftusageDeviceoptions, null, function(data) {
                var optionHtml = '';
                for (var i = 0; i < data.length; i++) {
                    var option = data[i].trim() == '' ? 'empty' : data[i];
                    optionHtml += '<option>';
                    optionHtml += option;
                    optionHtml += '</option>';
                }
                $('.select-1').html(optionHtml);
                $('.select2').select2();
            }, '.box-body');
        }

        /*设置一个默认显示的时间*/
        function setDefaultDate() {
            var defaultDate = date.getAfterDate(-90) + '-' + date.getCurrentDate(-1);
            $($('.reservation-1')[0]).val(defaultDate);
        }

        /*初始化线性图标*/
        function initLineChart() {
            // init user count chart
            $('#chart-line').removeClass('dom-hide');
            //删除canvas节点，避免重复绘制
            $('#lineChart').remove();
            $('#lineChartParent').append('<canvas class="line-chart" id="lineChart"></canvas>');
            var lineChartCanvas = $("#lineChart").get(0).getContext("2d");
            var lineChart = new Chart(lineChartCanvas);
            lineChart.Line(lineChartData, pluginsConfig.lineChartOptions);
            var lengndTemple = '';
            for (var i = 0; i < lineChartData.datasets.length; i++) {
                lengndTemple += '<li>';
                lengndTemple += '<span style="background-color: ' + lineChartData.datasets[i].strokeColor + ';"></span> ' + lineChartData.datasets[i].label;
                lengndTemple += '</li>';
            }
            $('#lineChartTemple').find('.list-inline').html(lengndTemple);

            // init device count chart
            //删除canvas节点，避免重复绘制
            $('#lineChart2').remove();
            $('#lineChartParent2').append('<canvas class="line-chart" id="lineChart2"></canvas>');
            var lineChart2Canvas = $("#lineChart2").get(0).getContext("2d");
            var lineChart2 = new Chart(lineChart2Canvas);
            lineChart2.Line(deviceLineCharData, pluginsConfig.lineChartOptions);
            var lengndTemple2 = '';
            for (var i = 0; i < deviceLineCharData.datasets.length; i++) {
                lengndTemple2 += '<li>';
                lengndTemple2 += '<span style="background-color: ' + deviceLineCharData.datasets[i].strokeColor + ';"></span> ' + deviceLineCharData.datasets[i].label;
                lengndTemple2 += '</li>';
            }
            $('#lineChartTemple2').find('.list-inline').html(lengndTemple2);
        }

        return atEnabledUsers;
    });
