/**
 * H5Account - Active Users 页 js
 *
 * @since 2016-01-21 11:00
 */
define(['jquery', 'daterangepicker', 'chart', 'select2', 'util', 'tools/http', 'pluginsConfig', 'validate', 'date'], function($,
    daterangepicker, chart, select2, util, http, pluginsConfig, validate, date) {
    'use strict';
    var h5aActiveUsers = {};

    var lineChartDailyCountData = {
        labels: [],
        datasets: []
    };

    var lineChartWeeklyCountData = {
        labels: [],
        datasets: []
    };

    h5aActiveUsers.execute = function() {
        initTimePicker();
        initSelect();
        initClick();
    };

    /*初始化点击事件*/
    function initClick() {
        /*设置csv文件下载路径*/
        $('#csv-link').bind('click', function() {
            var dateVal = $($('.reservation-1')[0]).val();
            if (validate.validateDate(dateVal, '#form-timepicker')) {
                var startDate = date.getDate(dateVal, true);
                var endDate = date.getDate(dateVal, false);
                var deviceVal = $($('.select-1')[0]).select2('val');
                var productVal = $($('.select-1')[1]).select2('val');
                var requestUrl = http.httpUrl.getVersion + http.httpUrl.getAccountusageActiveusersweekly +
                        '?startDate=' + startDate +
                        '&endDate=' + endDate +
                        '&format=csv';

                if (deviceVal) {
                    requestUrl = requestUrl + '&device=' + deviceVal;
                }
                if (productVal) {
                    requestUrl = requestUrl + '&product=' + productVal;
                }
                setDownloadCsvLink(requestUrl);
            }
        });

        /*设置daily csv文件下载路径*/
        $('#csv-link-2').bind('click', function() {
            var dateVal = $($('.reservation-1')[0]).val();
            if (validate.validateDate(dateVal, '#form-timepicker')) {
                var startDate = date.getDate(dateVal, true);
                var endDate = date.getDate(dateVal, false);
                var deviceVal = $($('.select-1')[0]).select2('val');
                var productVal = $($('.select-1')[1]).select2('val');
                var requestUrl = http.httpUrl.getVersion + http.httpUrl.getAccountusageActiveusersdaily +
                        '?startDate=' + startDate +
                        '&endDate=' + endDate +
                        '&format=csv';

                if (deviceVal) {
                    requestUrl = requestUrl + '&device=' + deviceVal;
                }
                if (productVal) {
                    requestUrl = requestUrl + '&product=' + productVal;
                }
                setDownloadCsvLink(requestUrl);
            }
        });

        //reset按钮点击事件
        $('.reset-btn').each(function(index) {
            $(this).click(function() {
                util.initResetClick(index + 1);
            });
        });
        //commit按钮点击事件
        $('.commit-btn').click(function() {
            initCommitClick();
        });
    }

    //初始化commit点击事件
    function initCommitClick() {
        var dateVal = $($('.reservation-1')[0]).val();
        if (validate.validateDate(dateVal, '#form-timepicker')) {
            var startDate = date.getDate(dateVal, true);
            var endDate = date.getDate(dateVal, false);
            // 获取Active User的Daily信息
            getDaysMsg(startDate, endDate, function() {
                // 获取Active User的Weekly信息
                getWeeksMsg(startDate, endDate);
            });
        }
    }

    /*获取Active User的Daily信息*/
    function getDaysMsg(startDate, endDate, callback) {
        var deviceVal = $($('.select-1')[0]).select2('val');
        var productVal = $($('.select-1')[1]).select2('val');
        var requestUrl = http.httpUrl.getAccountusageActiveusersdaily +
                '?startDate=' + startDate +
                '&endDate=' + endDate;

        if (deviceVal) {
            requestUrl = requestUrl + '&device=' + deviceVal;
        }
        if (productVal) {
            requestUrl = requestUrl + '&product=' + productVal;
        }
        //请求图表数据
        http.request('get', requestUrl, null, function(data, reqUrl) {
            var deviceList = data.data;
            var labelsArr = [];
            var dataSetsDailyCountArr = [];
            dataSetsDailyCountArr[0] = new pluginsConfig.lineDataStyle2();
            dataSetsDailyCountArr[0].label = 'daily count';
            for (var i = 0; i < deviceList.length; i++) {
                labelsArr[i] = deviceList[i].date;
                dataSetsDailyCountArr[0].data[i] = deviceList[i].count;
            }
            lineChartDailyCountData.labels = labelsArr;
            lineChartDailyCountData.datasets = dataSetsDailyCountArr;
            if (callback) {
                callback();
            }
        });
    }

    /*获取Active User的Weekly信息*/
    function getWeeksMsg(startDate, endDate) {
        var deviceVal = $($('.select-1')[0]).select2('val');
        var productVal = $($('.select-1')[1]).select2('val');
        var requestUrl = http.httpUrl.getAccountusageActiveusersweekly +
                '?startDate=' + startDate +
                '&endDate=' + endDate;

        if (deviceVal) {
            requestUrl = requestUrl + '&device=' + deviceVal;
        }
        if (productVal) {
            requestUrl = requestUrl + '&product=' + productVal;
        }
        //请求图表数据
        http.request('get', requestUrl, null, function(data, reqUrl) {
            var deviceList = data.data;
            var labelsArr = [];
            var dataSetsWeeklyCountArr = [];
            dataSetsWeeklyCountArr[0] = new pluginsConfig.lineDataStyle2();
            dataSetsWeeklyCountArr[0].label = 'weekly count';
            for (var i = 0; i < deviceList.length; i++) {
                labelsArr[i] = deviceList[i].week_start + '-' + deviceList[i].week_end;
                dataSetsWeeklyCountArr[0].data[i] = deviceList[i].count;
            }
            lineChartWeeklyCountData.labels = labelsArr;
            lineChartWeeklyCountData.datasets = dataSetsWeeklyCountArr;
            //初始化图表
            initLineChart();
        }, '.box-body');
    }

    /*生成csv文件下载链接*/
    function setDownloadCsvLink(url) {
        window.location.href = url;
    }

    /*初始化时间选择器*/
    function initTimePicker() {
        $('.reservation-1').daterangepicker({
            format: 'YYYY-MM-DD'
        });
        setDefaultDate();
    }

    /*设置一个默认显示的时间*/
    function setDefaultDate() {
        var defaultDate = date.getAfterDate(-90) + '-' + date.getCurrentDate(-1);
        $($('.reservation-1')[0]).val(defaultDate);
    }

    /*初始化下拉选择框*/
    function initSelect() {
        var reqUrl = http.httpUrl.getAccountusageOptions + '?params=device,product';
        //获取device 信息
        http.request('get', reqUrl, null, function(data) {
            var deviceHtml = '';
            var productHtml = '';
            for (var i = 0; i < data.device.length; i++) {
                var option = data.device[i].trim() == '' ? 'empty' : data.device[i];
                deviceHtml += '<option>';
                deviceHtml += option;
                deviceHtml += '</option>';
            }
            for (var i = 0; i < data.product.length; i++) {
                var option = data.product[i].trim() == '' ? 'empty' : data.product[i];
                productHtml += '<option>';
                productHtml += option;
                productHtml += '</option>';
            }
            $($('.select-1')[0]).html(deviceHtml);
            $($('.select-1')[1]).html(productHtml);
            $('.select2').select2();
        }, '.box-body');
    }

    /*初始化线性图表*/
    function initLineChart() {
        $('#chart-line').removeClass('dom-hide');
        //删除canvas节点，避免重复绘制
        $('#lineChart').remove();
        $('#lineChartParent').append('<canvas class="line-chart" id="lineChart"></canvas>');
        var lineChartCanvas = $("#lineChart").get(0).getContext("2d");
        var lineChart = new Chart(lineChartCanvas);
        lineChart.Line(lineChartDailyCountData, pluginsConfig.lineChartOptions);
        var lengndTemple = '';
        for (var i = 0; i < lineChartDailyCountData.datasets.length; i++) {
            lengndTemple += '<li>';
            lengndTemple += '<span style="background-color: ' + lineChartDailyCountData.datasets[i].strokeColor + ';"></span> ' + lineChartDailyCountData.datasets[i].label;
            lengndTemple += '</li>';
        }
        $('#lineChartTemple').find('.list-inline').html(lengndTemple);

        //删除canvas节点，避免重复绘制
        $('#lineChart2').remove();
        $('#lineChartParent2').append('<canvas class="line-chart" id="lineChart2"></canvas>');
        var lineChart2Canvas = $("#lineChart2").get(0).getContext("2d");
        var lineChart2 = new Chart(lineChart2Canvas);
        lineChart2.Line(lineChartWeeklyCountData, pluginsConfig.lineChartOptions);
        var lengndTemple2 = '';
        for (var i = 0; i < lineChartWeeklyCountData.datasets.length; i++) {
            lengndTemple2 += '<li>';
            lengndTemple2 += '<span style="background-color: ' + lineChartWeeklyCountData.datasets[i].strokeColor + ';"></span> ' + lineChartWeeklyCountData.datasets[i].label;
            lengndTemple2 += '</li>';
        }
        $('#lineChartTemple2').find('.list-inline').html(lengndTemple2);
    }

    return h5aActiveUsers;
});
