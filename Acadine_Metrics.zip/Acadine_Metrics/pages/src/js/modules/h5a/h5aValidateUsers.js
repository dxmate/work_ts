/**
 * H5Account - Validate Users 页 js
 * @since 2016-01-21 11:00
 */
define(['jquery', 'daterangepicker', 'chart', 'select2', 'util', 'tools/http', 'pluginsConfig', 'validate', 'date'], function($,
    daterangepicker, chart, select2, util, http, pluginsConfig, validate, date) {
    'use strict';
    var h5aActiveUsers = {};

    var lineChartValidateUserData = {
        labels: [],
        datasets: []
    };

    var lineChartTotalUserData = {
        labels: [],
        datasets: []
    };

    h5aActiveUsers.execute = function() {
        initTimePicker();
        initSelect();
        initClick();
    };

    /*初始化点击事件*/
    function initClick() {
        /*设置csv文件下载路径*/
        $('#csv-link').bind('click', function() {
            var dateVal = $($('.reservation-1')[0]).val();
            if (validate.validateDate(dateVal, '#form-timepicker')) {
                var startDate = date.getDate(dateVal, true);
                var endDate = date.getDate(dateVal, false);
                var refererVal = $('.select2').select2('val');
                var requestUrl = http.httpUrl.getVersion + http.httpUrl.getAccountusageValidatedusersTotal +
                        '?startDate=' + startDate +
                        '&endDate=' + endDate +
                        '&format=csv';

                if (refererVal) {
                    requestUrl = requestUrl + '&referer=' + refererVal;
                }
                setDownloadCsvLink(requestUrl);
            }
        });

        /*设置csv文件下载路径*/
        $('#csv-link-2').bind('click', function() {
            var dateVal = $($('.reservation-1')[0]).val();
            if (validate.validateDate(dateVal, '#form-timepicker')) {
                var startDate = date.getDate(dateVal, true);
                var endDate = date.getDate(dateVal, false);
                var refererVal = $('.select2').select2('val');
                var requestUrl = http.httpUrl.getVersion + http.httpUrl.getAccountusageValidatedusersdaily +
                        '?startDate=' + startDate +
                        '&endDate=' + endDate +
                        '&format=csv';

                if (refererVal) {
                    requestUrl = requestUrl + '&referer=' + refererVal;
                }
                setDownloadCsvLink(requestUrl);
            }
        });

        //reset点击事件
        $('.reset-btn').each(function(index) {
            $(this).click(function() {
                util.initResetClick(index + 1);
            });
        });
        //commit点击事件
        $('.commit-btn').click(function() {
            initCommitClick();
        });
    }

    /*初始化commit点击事件*/
    function initCommitClick() {
        var dateVal = $($('.reservation-1')[0]).val();
        if (validate.validateDate(dateVal, '#form-timepicker')) {
            var startDate = date.getDate(dateVal, true);
            var endDate = date.getDate(dateVal, false);

            //获取验证过的用户
            getVaildateUserMsg(startDate, endDate, function() {
                //获取所有用户
                getTotalUserMsg(startDate, endDate);
            });
        }
    }

    /*获取验证过的用户*/
    function getVaildateUserMsg(startDate, endDate, callback) {
        var refererVal = $('.select2').select2('val');
        var requestUrl = http.httpUrl.getAccountusageValidatedusersdaily +
                '?startDate=' + startDate +
                '&endDate=' + endDate;

        if (refererVal) {
            requestUrl = requestUrl + '&referer=' + refererVal;
        }
        //请求图表数据
        http.request('get', requestUrl, null, function(data, reqUrl) {
            var deviceList = data.data;
            var labelsArr = [];
            var dataSetsArr = [];
            dataSetsArr[0] = new pluginsConfig.lineDataStyle2();
            dataSetsArr[0].label = 'user count';
            for (var i = 0; i < deviceList.length; i++) {
                labelsArr[i] = deviceList[i].date;
                dataSetsArr[0].data[i] = deviceList[i].count;
            }
            lineChartValidateUserData.labels = labelsArr;
            lineChartValidateUserData.datasets = dataSetsArr;

            if (callback) {
                callback();
            }
        });
    }

    /*获取所有用户*/
    function getTotalUserMsg(startDate, endDate) {
        var refererVal = $('.select2').select2('val');
        var requestUrl = http.httpUrl.getAccountusageValidatedusersTotal +
                '?startDate=' + startDate +
                '&endDate=' + endDate;

        if (refererVal) {
            requestUrl = requestUrl + '&referer=' + refererVal;
        }
        //请求图表数据
        http.request('get', requestUrl, null, function(data, reqUrl) {
            var deviceList = data.data;
            var labelsArr = [];
            var dataSetsArr = [];
            dataSetsArr[0] = new pluginsConfig.lineDataStyle2();
            dataSetsArr[0].label = 'total count';
            for (var i = 0; i < deviceList.length; i++) {
                labelsArr[i] = deviceList[i].date;
                dataSetsArr[0].data[i] = deviceList[i].count;
            }
            lineChartTotalUserData.labels = labelsArr;
            lineChartTotalUserData.datasets = dataSetsArr;

            //初始化图表
            initLineChart();
        }, '.box-body');
    }

    /*生成csv文件下载链接*/
    function setDownloadCsvLink(url) {
        window.location.href = url;
    }

    /* init time picker */
    function initTimePicker() {
        $('.reservation-1').daterangepicker({
            format: 'YYYY-MM-DD'
        });
        setDefaultDate();
    }

    /*设置一个默认显示的时间*/
    function setDefaultDate() {
        var defaultDate = date.getAfterDate(-90) + '-' + date.getCurrentDate(-1);
        $($('.reservation-1')[0]).val(defaultDate);
    }

    /*初始化下拉选择框*/
    function initSelect() {
        var reqUrl = http.httpUrl.getAccountusageOptions + '?params=referer';
        //获取referers信息
        http.request('get', reqUrl, null, function(data) {
            var referersOptionHtml = '';
            for (var i = 0; i < data.referer.length; i++) {
                var option = data.referer[i].trim() == '' ? 'empty' : data.referer[i];
                referersOptionHtml += '<option>';
                referersOptionHtml += option;
                referersOptionHtml += '</option>';
            }
            $($('.select-1')[0]).html(referersOptionHtml);
            $('.select2').select2();
        }, '.box-body');
    }

    /*初始化线性图表*/
    function initLineChart() {
        $('#chart-line').removeClass('dom-hide');
        //删除canvas节点，避免重复绘制
        $('#lineChart').remove();
        $('#lineChartParent').append('<canvas class="line-chart" id="lineChart"></canvas>');
        var lineChartCanvas = $("#lineChart").get(0).getContext("2d");
        var lineChart = new Chart(lineChartCanvas);
        lineChart.Line(lineChartValidateUserData, pluginsConfig.lineChartOptions);
        var lengndTemple = '';
        for (var i = 0; i < lineChartValidateUserData.datasets.length; i++) {
            lengndTemple += '<li>';
            lengndTemple += '<span style="background-color: ' + lineChartValidateUserData.datasets[i].strokeColor + ';"></span> ' + lineChartValidateUserData.datasets[i].label;
            lengndTemple += '</li>';
        }
        $('#lineChartTemple').find('.list-inline').html(lengndTemple);

        //删除canvas节点，避免重复绘制
        $('#lineChart2').remove();
        $('#lineChartParent2').append('<canvas class="line-chart" id="lineChart2"></canvas>');
        var lineChart2Canvas = $("#lineChart2").get(0).getContext("2d");
        var lineChart2 = new Chart(lineChart2Canvas);
        lineChart2.Line(lineChartTotalUserData, pluginsConfig.lineChartOptions);
        var lengndTemple2 = '';
        for (var i = 0; i < lineChartTotalUserData.datasets.length; i++) {
            lengndTemple2 += '<li>';
            lengndTemple2 += '<span style="background-color: ' + lineChartTotalUserData.datasets[i].strokeColor + ';"></span> ' + lineChartTotalUserData.datasets[i].label;
            lengndTemple2 += '</li>';
        }
        $('#lineChartTemple2').find('.list-inline').html(lengndTemple2);
    }

    return h5aActiveUsers;
});
