/**
 * header js
 * @since 2016-1-21 14:52
 */
define(['jquery', 'tools/http'], function($, http) {
    'use strict';
    var header = {};

    /*初始化*/
    header.init = function() {
        initClick();
        getUserInfo();
    };

    /*获取用户信息*/
    var getUserInfo = function() {
        http.request('get', http.httpUrl.getUserInfo, null, function(data) {
            $('#name').html('<a href="#">' + data.name + '</a>');
        });
    };

    /*初始化点击事件,执行退出登陆操作*/
    var initClick = function() {
        $('#logout-btn').click(function() {
            http.request('post', http.httpUrl.logOut, null, function(data) {
                window.location.href = data;
            });
        });
    };

    return header;
});