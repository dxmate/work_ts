/**
 * menu js
 * @since 2016-1-21 11:00
 */
define(['jquery', 'tools/http'], function($, http) {
    'use strict';
    var menu = {};

    /*初始化点击事件*/
    var initClick = function() {
        require(['app/mainApp'], function(mainApp) {
            $('[target-url]').each(function() {
                $(this).click(function() {
                    $('.sidebar-menu li').removeClass('active');
                    $(this).parent().addClass('active');
                    var targetUrl = $(this).attr('target-url');
                    var targetJs = $(this).attr('target-js');
                    mainApp.switchContent([targetUrl, targetJs]);
                });
            });
        });
    };

    /*设置菜单列表树*/
    function getDomTree(menuData) {
        for (var i = 0; i < menuData.length; i++) {
            var isChild = menuData[i].children;
            strHtml += '<li class="treeview">';
            if (isChild.length > 0) {
                strHtml += '<a>';
            } else {
                strHtml += '<a target-url="'+ menuData[i].url + '" target-js="'+ menuData[i]['js'] + '">';
            }
            strHtml += '<i class="' + menuData[i].icon + '"></i>';
            strHtml += '<span> ' + menuData[i].text + '</span>';
            if(isChild.length > 0){
                strHtml += '<i class="icon-angle-left pull-right"></i>';
            }
            strHtml += '</a>';
            if (isChild.length > 0) {
                strHtml += '<ul class="treeview-menu">';
                getDomTree(menuData[i].children);
                strHtml += '</ul>';
            }
            strHtml += '</li>';
        }
    }

    var strHtml = '';
    /*初始化菜单列表树*/
    menu.initMenuList = function() {
        //get menu request
        http.request('get', http.httpUrl.getMenu, null, function(data) {
            getDomTree(data);
            $(".sidebar-menu").append(strHtml);
            initClick();
        }, '.main-sidebar');
    };

    return menu;
});