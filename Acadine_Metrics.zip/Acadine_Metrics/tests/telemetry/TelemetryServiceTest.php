<?php

use Module\common\config\ApiUriConfig;
use Module\adapter\service\impl\TelemetryService;

/**
 * Class TelemetryServiceTest
 */
class TelemetryServiceTest extends APIv1TestCase
{
    /**
     * this function of telemetryservice is used for test get sum ftu
     */
    public function testGetFtuSum()
    {
        $result = TelemetryService::getInstance()->getFtuSum(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_SUM)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of telemetryservice is used for test get daily ftu
     */
    public function testGetFtuDaily()
    {
        $result = TelemetryService::getInstance()->getFtuDaily(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_DAILY)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of telemetryservice is used for test get ftu options
     */
    public function testGetFtuOptions()
    {
        $testData = implode(',', self::TEST_TLOPTIONS_DATA);
        $result = TelemetryService::getInstance()->getFtuOptions($testData);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_OPTIONS)];
        $this->assertEquals($expect, $result['data']);
    }
}
