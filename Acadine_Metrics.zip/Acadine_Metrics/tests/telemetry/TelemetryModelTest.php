<?php

use Module\common\config\ApiUriConfig;
use Module\adapter\model\impl\TelemetryModel;
use Module\common\config\AdapterParamKeys;

/**
 * Class TelemetryModelTest
 */
class TelemetryModelTest extends APIv1TestCase
{
    /**
     * this function of telemetrymodel is used for test get sum ftu
     */
    public function testGetFtuSum()
    {
        $result = TelemetryModel::getInstance()->getFtuSum(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_SUM)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of telemetrymodel is used for test get daily ftu
     */
    public function testGetFtuDaily()
    {
        $result = TelemetryModel::getInstance()->getFtuDaily(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_DAILY)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of telemetrymodel is used for test get ftu options
     */
    public function testGetFtuOptions()
    {
        $result = TelemetryModel::getInstance()->getFtuOptions(self::TEST_TLOPTIONS_DATA[0], self::TEST_TLOPTIONS_DATA[1]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_OPTIONS)];
        $this->assertEquals($expect, $data);
    }
}
