<?php

use Module\common\config\ApiUriConfig;

/**
 * Class TelemetryTest
 */
class TelemetryTest extends APIv1TestCase
{
    /**
     * this function of telemetry is used for test sum ftu
     */
    public function testFtusum()
    {
        $this->client->post(self::TEST_FTU_SUM_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_SUM)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of telemetry is used for test daily ftu
     */
    public function testFtudaily()
    {
        $this->client->post(self::TEST_FTU_DAILY_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_DAILY)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of telemetry is used for test ftu options
     */
    public function testFtuoptions()
    {
        $this->client->post(self::TEST_FTU_OPTIONS_URI, self::TEST_TLOPTIONS_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_OPTIONS)];
        $this->assertEquals($expect, $data['info']);
    }
}
