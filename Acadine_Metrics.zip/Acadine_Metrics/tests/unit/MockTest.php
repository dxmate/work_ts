<?php
use Core\common\HttpClient;

/**
 * test httpclient mock
 */
class MockTest extends APIv1TestCase
{

    public function testMork()
    {
        $response = HttpClient::getInstance()->get('url');
        $content = file_get_contents(APP_PATH . 'Module/v1/mock/data/testmock.json');
        $result = json_decode($content, true);
        $expected = json_encode($result['url']);
        $this->assertEquals($expected, $response->getBody());
    }
}
