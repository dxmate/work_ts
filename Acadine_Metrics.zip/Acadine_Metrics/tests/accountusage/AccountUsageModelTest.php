<?php

use Module\common\config\ApiUriConfig;
use Module\common\config\AdapterParamKeys;
use Module\adapter\model\impl\AccountUsageModel;

/**
 * Class AccountUsageModelTest
 */
class AccountUsageModelTest extends APIv1TestCase
{
    /**
     * this function of accountusagemodel is used for test get validated daily users
     */
    public function testGetValidatedusersDaily()
    {
        $result = AccountUsageModel::getInstance()->getValidatedusersDaily(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_DAILY)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of accountusagemodel is used for test get validated total users
     */
    public function testGetValidatedusersTotal()
    {
        $result = AccountUsageModel::getInstance()->getValidatedusersTotal(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_TOTAL)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of accountusagemodel is used for test get active daily users
     */
    public function testGetActiveusersDaily()
    {
        $result = AccountUsageModel::getInstance()->getActiveusersDaily(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_DAILY)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of accountusagemodel is used for test get active weekly users
     */
    public function testGetActiveusersWeekly()
    {
        $result = AccountUsageModel::getInstance()->getActiveusersWeekly(self::TEST_WEEK_DATA[AdapterParamKeys::START_WEEK], self::TEST_WEEK_DATA[AdapterParamKeys::END_WEEK]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_WEEKLY)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of accountusagemodel is used for test get options
     */
    public function testGetOptions()
    {
        $result = AccountUsageModel::getInstance()->getOptions(self::TEST_ACOPTIONS_DATA[0], self::TEST_ACOPTIONS_DATA[1], self::TEST_ACOPTIONS_DATA[2]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_OPTIONS)];
        $this->assertEquals($expect, $data);
    }
}
