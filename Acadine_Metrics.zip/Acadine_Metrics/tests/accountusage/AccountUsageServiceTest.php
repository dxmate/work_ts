<?php

use Module\common\config\ApiUriConfig;
use Module\adapter\service\impl\AccountUsageService;

/**
 * Class AccountUsageServiceTest
 */
class AccountUsageServiceTest extends APIv1TestCase
{
    /**
     * this function of accountusageservice is used for test get validated daily users
     */
    public function testGetValidatedusersDaily()
    {
        $result = AccountUsageService::getInstance()->getValidatedusersDaily(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_DAILY)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of accountusageservice is used for test get validated total users
     */
    public function testGetValidatedusersTotal()
    {
        $result = AccountUsageService::getInstance()->getValidatedusersTotal(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_TOTAL)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of accountusageservice is used for test get active daily users
     */
    public function testGetActiveusersDaily()
    {
        $result = AccountUsageService::getInstance()->getActiveusersDaily(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_DAILY)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of accountusageservice is used for test get active weekly users
     */
    public function testGetActiveusersWeekly()
    {
        $result = AccountUsageService::getInstance()->getActiveusersWeekly(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_WEEKLY)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of accountusageservice is used for test get options
     */
    public function testGetOptions()
    {
        $result = AccountUsageService::getInstance()->getOptions(self::TEST_ACOPTIONS_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_OPTIONS)];
        $this->assertEquals($expect, $result['data']);
    }
}
