<?php

use Module\common\config\ApiUriConfig;

/**
 * Class AccountUsageTest
 */
class AccountUsageTest extends APIv1TestCase
{
    /**
     * this function of accountusage is used for test validated daily users
     */
    public function testValidatedUsersDaily()
    {
        $this->client->post(self::TEST_VALIDATED_USERS_DAILY_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_DAILY)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of accounsusage is used for test validated total users
     */
    public function testValidatedUsersTotal()
    {
        $this->client->post(self::TEST_VALIDATED_USERS_TOTAL_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_TOTAL)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of accountusage is used for test active daily users
     */
    public function testActiveUsersDaily()
    {
        $this->client->post(self::TEST_ACTIVE_USERS_DAILY_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_DAILY)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of accountusage is used for test active weekly users
     */
    public function testActiveUsersWeekly()
    {
        $this->client->post(self::TEST_ACTIVE_USERS_WEEKLY_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_WEEKLY)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of accountusage is used for test options
     */
    public function testOptions()
    {
        $this->client->post(self::TEST_OPTIONS_URI, self::TEST_ACOPTIONS_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::H5A_V1_OPTIONS)];
        $this->assertEquals($expect, $data['info']);
    }
}
