<?php

use Module\common\config\ApiUriConfig;
use Module\common\config\AdapterParamKeys;
use Module\adapter\model\impl\AntitheftUsageModel;

/**
 * Class AntitheftUsageModelTest
 */
class AntitheftUsageModelTest extends APIv1TestCase
{
    /**
     * this function of antitheftusagemodel is used for test get sum enabled
     */
    public function testGetEnabledSum()
    {
        $result = AntitheftUsageModel::getInstance()->getEnabledSum(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_ENABLED_SUM)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of antitheftusagemodel is used for test get daily lock
     */
    public function testGetLockDaily()
    {
        $result = AntitheftUsageModel::getInstance()->getLockDaily(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_LOCK_DAILY)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of antitheftusagemodel is used for test get daily wipe
     */
    public function testGetWipeDaily()
    {
        $result = AntitheftUsageModel::getInstance()->getWipeDaily(self::TEST_DATA[AdapterParamKeys::START_DATE], self::TEST_DATA[AdapterParamKeys::END_DATE]);
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_WIPE_DAILY)];
        $this->assertEquals($expect, $data);
    }

    /**
     * this function of antitheftusagemodel is used for test get device options
     */
    public function testGetDeviceOptions()
    {
        $result = AntitheftUsageModel::getInstance()->getDeviceOptions();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_DEVICE_OPTIONS)];
        $this->assertEquals($expect, $data);
    }
}
