<?php

use Module\common\config\ApiUriConfig;
use Module\adapter\service\impl\AntitheftUsageService;

/**
 * Class AntitheftUsageServiceTest
 */
class AntitheftUsageServiceTest extends APIv1TestCase
{
    /**
     * this function of antitheftusageservice is used for test get sum enabled
     */
    public function testGetEnabledSum()
    {
        $result = AntitheftUsageService::getInstance()->getEnabledSum(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_ENABLED_SUM)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of antitheftusageservice is used for test get daily lock
     */
    public function testGetLockDaily()
    {
        $result = AntitheftUsageService::getInstance()->getLockDaily(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_LOCK_DAILY)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of antitheftusageservice is used for test get daily wipe
     */
    public function testGetWipeDaily()
    {
        $result = AntitheftUsageService::getInstance()->getWipeDaily(self::TEST_DATA);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_WIPE_DAILY)];
        $this->assertEquals($expect, $result['data']);
    }

    /**
     * this function of antitheftusageservice is used for test get device options
     */
    public function testGetDeviceOptions()
    {
        $result = AntitheftUsageService::getInstance()->getDeviceOptions();
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_DEVICE_OPTIONS)];
        $this->assertEquals($expect, $result['data']);
    }
}
