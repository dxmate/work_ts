<?php

use Module\common\config\ApiUriConfig;

/**
 * Class AntitheftUsageTest
 */
class AntitheftUsageTest extends APIv1TestCase
{
    /**
     * this function of antitheftusage is used for test sum enabled
     */
    public function testEnabledSum()
    {
        $this->client->post(self::TEST_ENABLED_SUM_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_ENABLED_SUM)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of antitheftusage is used for test daily lock
     */
    public function testLockDaily()
    {
        $this->client->post(self::TEST_LOCK_DAILY_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_LOCK_DAILY)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of antitheftusage is used for test daily wipe
     */
    public function testWipeDaily()
    {
        $this->client->post(self::TEST_WIPE_DAILY_URI, self::TEST_DATA);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_WIPE_DAILY)];
        $this->assertEquals($expect, $data['info']);
    }

    /**
     * this function of antitheftusage is used for test device options
     */
    public function testDeviceOptions()
    {
        $test = array();
        $this->client->post(self::TEST_DEVICE_OPTIONS_URI, $test);
        $result = $this->client->response->getBody();
        $data = json_decode($result, true);
        $expect = $this->mockResponses[ApiUriConfig::get(ApiUriConfig::AT_V1_DEVICE_OPTIONS)];
        $this->assertEquals($expect, $data['info']);
    }
}
