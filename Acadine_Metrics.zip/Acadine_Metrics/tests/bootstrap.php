<?php

use Module\v1\mock\Mock;
use Module\common\config\AdapterParamKeys;

// Settings to make all errors more obvious during testing
error_reporting(-1);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
date_default_timezone_set('UTC');

define('APP_PATH', __DIR__.'/../');
require APP_PATH.'vendor/autoload.php';
require APP_PATH.'Core/common/Functions.php';

// Initialize our own copy of the slim application
class LocalWebTestCase extends There4\Slim\Test\WebTestCase
{
    public function getSlimInstance()
    {
        \Slim\Environment::mock();
        $app = new \Slim\Slim([
            'version' => '0.1',
            'debug' => true,
            'mode' => 'testing',
        ]);
        Core\lib\App::init($app);
        $projInitFile = APP_PATH.'/Module/common/Init.php';
        if (file_exists($projInitFile)) {
            require $projInitFile;
        }

        return $app;
    }
}

class APIv1TestCase extends LocalWebTestCase
{
    const TEST_START_DATE = '2016-01-01';
    const TEST_END_DATE = '2016-01-02';
    const TEST_START_WEEK = 23;
    const TEST_END_WEEK = 24;
    const TEST_DATA = array(
        AdapterParamKeys::START_DATE => self::TEST_START_DATE,
        AdapterParamKeys::END_DATE => self::TEST_END_DATE
    );
    const TEST_WEEK_DATA = array(
        AdapterParamKeys::START_WEEK => self::TEST_START_WEEK,
        AdapterParamKeys::END_WEEK => self::TEST_END_WEEK
    );
    const TEST_TLOPTIONS_DATA = array(
        0 => AdapterParamKeys::COUNTRY,
        1 => AdapterParamKeys::CHIPSET
    );
    const TEST_ACOPTIONS_DATA = array(
        0 => AdapterParamKeys::REFERER,
        1 => AdapterParamKeys::DEVICE,
        2 => AdapterParamKeys::SERVICE
    );
    const TEST_VALIDATED_USERS_DAILY_URI = '/v1/accountusage/validatedusersdaily';
    const TEST_VALIDATED_USERS_TOTAL_URI = '/v1/accountusage/validateduserstotal';
    const TEST_ACTIVE_USERS_DAILY_URI = '/v1/accountusage/activeusersdaily';
    const TEST_ACTIVE_USERS_WEEKLY_URI = '/v1/accountusage/activeusersweekly';
    const TEST_OPTIONS_URI = '/v1/accountusage/options';
    const TEST_ENABLED_SUM_URI = '/v1/antitheftusage/enabledsum';
    const TEST_LOCK_DAILY_URI = '/v1/antitheftusage/lockdaily';
    const TEST_WIPE_DAILY_URI = '/v1/antitheftusage/wipedaily';
    const TEST_DEVICE_OPTIONS_URI = '/v1/antitheftusage/deviceoptions';
    const TEST_FTU_SUM_URI = '/v1/telemetry/ftusum';
    const TEST_FTU_DAILY_URI = '/v1/telemetry/ftudaily';
    const TEST_FTU_OPTIONS_URI = '/v1/telemetry/ftuoptions';
    protected $mockResponses;

    public function setup()
    {
        parent::setup();
        $this->app->hook('slim.before.router', function () {
            Mock::mockLoginUser($this->app);
        });
        $this->mockResponses = Mock::morkServerHttpApiData();
    }
}
