<?php

define('APP_PATH', __DIR__.'/../');

require APP_PATH.'Core/Core.php';


