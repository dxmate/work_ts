define(["jquery","tools/http"],function(n,t){"use strict";function i(){n("#login-btn").click(function(){window.location.href=t.httpUrl.login})}var o={};return n(function(){i()}),o});
//# sourceMappingURL=../maps/app/welcomeApp.js.map
