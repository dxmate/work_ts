require(["common"],function(e){"use strict";require(["app/welcomeApp"])});
//# sourceMappingURL=maps/welcome.js.map
