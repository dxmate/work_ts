define(["jquery","select2"],function(e,t){"use strict";var n={};return n.initResetClick=function(t){e(".select-"+t).each(function(){e(this).select2("val","")}),e(".reservation-"+t).val("")},n.trimAll=function(e){return e.replace(/\s/g,"")},n});
//# sourceMappingURL=../maps/tools/util.js.map
