<?php

namespace Module\common\exception;

/**
 * for adapter exceptions.
 */
class AdapterException extends ContextException
{
}
