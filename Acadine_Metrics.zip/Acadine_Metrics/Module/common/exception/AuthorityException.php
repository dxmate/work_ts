<?php

namespace Module\common\exception;

/**
 * for logic errors.
 */
class AuthorityException extends ContextException
{
}
