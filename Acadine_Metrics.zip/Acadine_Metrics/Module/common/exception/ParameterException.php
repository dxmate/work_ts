<?php

namespace Module\common\exception;

/**
 * for parameter exceptions.
 */
class ParameterException extends ContextException
{
}
