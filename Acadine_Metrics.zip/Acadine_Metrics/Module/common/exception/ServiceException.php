<?php

namespace Module\common\exception;

/**
 * for logic errors.
 */
class ServiceException extends ContextException
{
}
