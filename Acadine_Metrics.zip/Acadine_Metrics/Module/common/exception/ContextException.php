<?php

namespace Module\common\exception;

/**
 * for context exceptions.
 */
class ContextException extends \Exception
{
}
