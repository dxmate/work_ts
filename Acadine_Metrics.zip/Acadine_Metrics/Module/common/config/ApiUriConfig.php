<?php
/**
 * ApiUriConfig
 * 接口路由配置
 * @author wanghu1209@thundersoft.com
 */

namespace Module\common\config;

use Core\lib\Config;

/**
 * This class is used to define api uri.
 */
class ApiUriConfig
{
    const API_HOST_ACCOUNT = 'API_HOST_ACCOUNT';

    const API_HOST_AMS = 'API_HOST_AMS';

    const AT_V1_ENABLED_SUM = 1;

    const AT_V1_LOCK_DAILY = 2;

    const AT_V1_WIPE_DAILY = 3;

    const AT_V1_DEVICE_OPTIONS = 4;

    const H5A_V1_VALIDATEDUSERS_DAILY = 5;

    const H5A_V1_VALIDATEDUSERS_TOTAL = 6;

    const H5A_V1_ACTIVEUSERS_DAILY = 7;

    const H5A_V1_ACTIVEUSERS_WEEKLY = 8;

    const H5A_V1_OPTIONS = 9;

    const TL_V1_FTU_SUM = 10;

    const TL_V1_FTU_DAILY = 11;

    const TL_V1_FTU_OPTIONS = 12;

    private static $apis = [
        self::AT_V1_ENABLED_SUM => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/antitheftusage/v1/enabled/sum',
        ],
        self::AT_V1_LOCK_DAILY => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/antitheftusage/v1/lock/daily',
        ],
        self::AT_V1_WIPE_DAILY => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/antitheftusage/v1/wipe/daily',
        ],
        self::AT_V1_DEVICE_OPTIONS => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/antitheftusage/v1/device/options',
        ],
        self::H5A_V1_VALIDATEDUSERS_DAILY => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/accountusage/v1/validatedusers/daily',
        ],
        self::H5A_V1_VALIDATEDUSERS_TOTAL => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/accountusage/v1/validatedusers/total',
        ],
        self::H5A_V1_ACTIVEUSERS_DAILY => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/accountusage/v1/activeusers/daily',
        ],
        self::H5A_V1_ACTIVEUSERS_WEEKLY => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/accountusage/v1/activeusers/weekly',
        ],
        self::H5A_V1_OPTIONS => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/accountusage/v1/options',
        ],
        self::TL_V1_FTU_SUM => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/telemetry/v1/ftu/sum',
        ],
        self::TL_V1_FTU_DAILY => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/telemetry/v1/ftu/daily',
        ],
        self::TL_V1_FTU_OPTIONS => [
            'host' => self::API_HOST_ACCOUNT,
            'uri' => '/telemetry/v1/ftu/options',
        ],
    ];

    public static function get($apiCode)
    {
        $api = self::$apis[$apiCode];

        return Config::get($api['host']).$api['uri'];
    }
}
