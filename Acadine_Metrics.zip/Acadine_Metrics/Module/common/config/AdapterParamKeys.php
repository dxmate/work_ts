<?php
/**
 * AdapterParamKeys
 * Adapter 参数键值
 * @author chencheng0312@thundersoft.com
 */

namespace Module\common\config;

/**
 * This class is used to define adapter's param.
 */
class AdapterParamKeys
{
    const START_DATE = 'startDate';

    const END_DATE = 'endDate';

    const START_WEEK = 'startWeek';

    const END_WEEK = 'endWeek';

    const FORMAT = 'format';

    const DEVICE = 'device';

    const PRODUCT = 'product';

    const REFERER = 'referer';

    const FORMAT_CSV = 'csv';

    const OPERATOR_SYS = 'os';

    const OPERATOR = 'operator';

    const COUNTRY = 'country';

    const CHIPSET = 'chipset';

    const PARAMS = 'params';

    const SERVICE = 'service';

    const API_KEY = 'api_key';

    const TS = 'ts';

    const HMAC = 'hmac';
}
