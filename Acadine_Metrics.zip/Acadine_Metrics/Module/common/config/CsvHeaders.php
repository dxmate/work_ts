<?php
/**
 * CsvHeaders
 * Csv头
 * @author wanghu1209@thundersoft.com
 */

namespace Module\common\config;

/**
 * This class is used to define csv headers.
 */
class CsvHeaders
{
    const H5A_V1_VALIDATEDUSERS_DAILY = ['date', 'count'];

    const H5A_V1_VALIDATEDUSERS_TOTAL = ['date', 'count'];

    const H5A_V1_ACTIVEUSERS_DAILY = ['date', 'count'];

    const H5A_V1_ACTIVEUSERS_WEEKLY = ['start-week', 'end-week', 'count'];

    const A_V1_ENABLEDUSERS_SUM = ['date', 'user-count', 'device-count'];

    const A_V1_LOCKUSERS_DAILY = ['date', 'user-count', 'action-count'];

    const A_V1_WIPEUSERS_DAILY = ['date', 'user-count', 'action-count'];

    const TL_V1_FTU_DAILY = ['date', 'count'];
}
