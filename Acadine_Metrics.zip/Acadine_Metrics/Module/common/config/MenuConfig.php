<?php
/**
 * MenuConfig
 * 菜单配置信息
 * @author wanghu1209@thundersoft.com
 */

namespace Module\common\config;

class MenuConfig
{
    const KEY_TEXT = 'text';

    const KEY_ICON = 'icon';

    const KEY_URL = 'url';

    const KEY_JS = 'js';

    const KEY_AUTHORITY = 'authority';

    const KEY_CHILDREN = 'children';

    const WEB_PAGE_MODULES = 'modules';

    const WEB_PAGE_FOLDER = '/pages';

    private static $menus = [
        [
            self::KEY_TEXT => 'Smart Feature Phone',
            self::KEY_ICON => 'icon-tablet',
            self::KEY_CHILDREN => [
                [
                    self::KEY_TEXT => 'Activation',
                    self::KEY_ICON => 'icon-circle-blank',
                    self::KEY_URL => self::WEB_PAGE_MODULES.'/sfp/sfp-activation.html',
                    self::KEY_JS => self::WEB_PAGE_MODULES.'/sfp/sfpActivation',
                    self::KEY_CHILDREN => [],
                ],
            ],
        ],
        [
            self::KEY_TEXT => 'H5 Account',
            self::KEY_ICON => 'icon-user',
            self::KEY_CHILDREN => [
                [
                    self::KEY_TEXT => 'Validated Users',
                    self::KEY_ICON => 'icon-circle-blank',
                    self::KEY_URL => self::WEB_PAGE_MODULES.'/h5a/h5a-validate-users.html',
                    self::KEY_JS => self::WEB_PAGE_MODULES.'/h5a/h5aValidateUsers',
                    self::KEY_CHILDREN => [],
                ],
                [
                    self::KEY_TEXT => 'Active Users',
                    self::KEY_ICON => 'icon-circle-blank',
                    self::KEY_URL => self::WEB_PAGE_MODULES.'/h5a/h5a-active-users.html',
                    self::KEY_JS => self::WEB_PAGE_MODULES.'/h5a/h5aActiveUsers',
                    self::KEY_CHILDREN => [],
                ],
            ],
        ],
        [
            self::KEY_TEXT => 'Anti Theft',
            self::KEY_ICON => 'icon-key',
            self::KEY_CHILDREN => [
                [
                    self::KEY_TEXT => 'Enabled Users',
                    self::KEY_ICON => 'icon-circle-blank',
                    self::KEY_URL => self::WEB_PAGE_MODULES.'/at/at-enabled-users.html',
                    self::KEY_JS => self::WEB_PAGE_MODULES.'/at/atEnabledUsers',
                    self::KEY_CHILDREN => [],
                ],
                [
                    self::KEY_TEXT => 'Lock Usage',
                    self::KEY_ICON => 'icon-circle-blank',
                    self::KEY_URL => self::WEB_PAGE_MODULES.'/at/at-lock-usage.html',
                    self::KEY_JS => self::WEB_PAGE_MODULES.'/at/atLockUsage',
                    self::KEY_CHILDREN => [],
                ],
                [
                    self::KEY_TEXT => 'Wipe Usage',
                    self::KEY_ICON => 'icon-circle-blank',
                    self::KEY_URL => self::WEB_PAGE_MODULES.'/at/at-wipe-usage.html',
                    self::KEY_JS => self::WEB_PAGE_MODULES.'/at/atWipeUsage',
                    self::KEY_CHILDREN => [],
                ],
            ],
        ],
    ];

    public static function getMenuConfig()
    {
        return self::$menus;
    }
}
