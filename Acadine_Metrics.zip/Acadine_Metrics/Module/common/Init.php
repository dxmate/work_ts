<?php

use Module\v1\mock\Mock;
use Core\lib\Config;
use Module\common\config\MenuConfig;
use Module\User\service\impl\UserService;

// This file will be used to handle some public events
$app->notFound(function () {
    echo 'page not found';
});
if (Config::get('mode') == 'dev-mock') {
    Mock::mockLoginUser($app);
    Mock::morkServerHttpApiData();
}
$app->get('/', function () use ($app) {
    $token = $app->getCookie('token');
    if (is_null($token)) {
        $app->redirect(MenuConfig::WEB_PAGE_FOLDER.'/welcome.html');
    }
    $loginUser = UserService::getInstance()->getLoginUserByToken($token);
    if (is_null($loginUser)) {
        $app->redirect(MenuConfig::WEB_PAGE_FOLDER.'/welcome.html');
    }
    $app->redirect(MenuConfig::WEB_PAGE_FOLDER);
});
