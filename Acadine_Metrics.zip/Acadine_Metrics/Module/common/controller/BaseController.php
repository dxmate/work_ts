<?php
/**
 * BaseController
 * 基础控制器
 * @author fengfei1124@thundersoft.com
 */

namespace Module\common\controller;

use Core\lib\Controller;
use Module\common\ErrorNo;
use Module\common\exception\ContextException;
use Module\User\service\impl\UserService;
use Module\User\vo\LoginUser;

class BaseController extends Controller
{
    /**
     * @var \Module\User\vo\LoginUser
     */
    protected $loginUser;

    /**
     * set app
     * the method will be called when controller instance,so some data initialization or verify allowed here.
     */
    public function beforeAction(\Slim\Slim $app, array $params)
    {
        parent::beforeAction($app, $params);
        $token = $this->app->getCookie('token');
        if (is_null($token)) {
            throw new ContextException(null, ErrorNo::ERR_UNAUTHORIZED);
        }

        $this->loginUser = UserService::getInstance()->getLoginUserByToken($token);
        if (is_null($this->loginUser)) {
            throw new ContextException(null, ErrorNo::ERR_UNAUTHORIZED);
        }
    }
}
