<?php
/**
 * ApiBaseController
 * 基础接口控制器，继承于基础控制器
 * @author fengfei1124@thundersoft.com
 */

namespace Module\common\controller;

use Core\common\HttpException;
use Core\lib\Config;
use Module\common\ErrorNo;
use Module\common\exception\ContextException;
use Core\common\HttpCode;

class ApiBaseController extends BaseController
{
    private $postParams;

    private $getParams;

    protected $requestParams;

    /**
     * this method will be called when controller instance,so some data initialization or verify allowed here.
     */
    public function beforeAction(\Slim\Slim $app, array $params)
    {
        parent::beforeAction($app, $params);
        $app->response()->header('Content-Type', 'Application/json;charset=UTF-8');
        $this->getParams = $app->request()->get();
        $this->postParams = $app->request()->post();
        $this->requestParams = array_merge($this->getParams, $this->postParams);
    }

    /**
     * this function is used for set response csv file format.
     *
     * @param string $fileName
     * @param string $csvData
     */
    protected function responseCsv(string $fileName, string $csvData)
    {
        $this->app->response()->header('Content-Type', 'application/csv;charset=UTF8');
        $this->app->response()->header('Content-Disposition', 'attachment;filename='.$fileName);
        $this->app->response()->body($csvData);
    }

    /**
     * this function is used for set response json file format.
     *
     * @param string $msg
     * @param string $info
     */
    protected function responseJson(string $msg, array $info)
    {
        $this->app->response->body(json_encode([
            'status' => HttpCode::HTTP_SUCCESS,
            'errno' => 0,
            'msg' => $msg,
            'info' => $info,
        ]));
    }

    /**
     * this method will be called after action method called.
     *
     * @param \Exception $e
     */
    public function afterAction($e)
    {
        if (!is_null($e) && ($e instanceof ContextException || $e instanceof HttpException)) {
            $this->exceptionResponse($e);
        } elseif (!is_null($e)) {
            if (Config::get('debug')) {
                throw $e;
            }
            $this->exceptionResponse($e);
        }
    }

    private function exceptionResponse(\Exception $e)
    {
        if ($e instanceof HttpException) {
            $errorNo = ErrorNo::getErr(ErrorNo::ERR_DATA_SERVER_UNAVAILABLE);
        } else {
            $errorNo = ErrorNo::getErr($e->getCode());
        }
        if (!$errorNo) {
            $errorNo = ErrorNo::getErr(ErrorNo::ERR_SYSTEM);
            if ($e->getMessage()) {
                $errorNo['msg'] = $e->getMessage();
            }
        }
        if (!is_null($e->getMessage()) && $e->getMessage() != '') {
            $errorNo['msg'] = $e->getMessage();
        }
        $errorNo['msg'] = $errorNo['msg'];
        $this->app->response()->header('Content-Type', 'Application/json;charset=UTF-8');
        $this->app->response->setStatus($errorNo['status']);
        $this->app->response->write(json_encode($errorNo));
    }
}
