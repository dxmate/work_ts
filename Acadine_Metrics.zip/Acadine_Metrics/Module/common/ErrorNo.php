<?php
/**
 * ErrorNo
 * 定义错误类型代码，错误信息
 * @author fengfei1124@thundersoft.com
 */

namespace Module\common;

/**
 * This class is used to define error code.
 */
class ErrorNo
{
    const ERR_NON_JSON = 101;

    const ERR_INVALID_PARAM = 102;

    const ERR_MISSING_PARAM = 103;

    const ERR_UNKNOWN_PARAM = 104;

    const ERR_OAUTH2_CODE = 105;

    const ERR_UNAUTHORIZED = 121;

    const ERR_INVALID_CLIENT_IP = 122;

    const ERR_NO_PERMISSION = 141;

    const ERR_API_NOT_FOUND = 161;

    const ERR_SYSTEM = 201;

    const ERR_SYS_DATABASE = 202;

    const ERR_NETWORK = 203;

    const ERR_DATA_RESPONSE = 204;

    const ERR_DATA_SERVER_UNAVAILABLE = 221;

    private static $errors = [
        self::ERR_NON_JSON => [
            'status' => 400,
            'errno' => 101,
            'msg' => 'request body was not a valid JSON',
        ],
        self::ERR_INVALID_PARAM => [
            'status' => 400,
            'errno' => 102,
            'msg' => 'request body contains invalid parameters',
        ],
        self::ERR_MISSING_PARAM => [
            'status' => 400,
            'errno' => 103,
            'msg' => 'request body missing required parameters',
        ],
        self::ERR_UNKNOWN_PARAM => [
            'status' => 400,
            'errno' => 104,
            'msg' => 'request body contains unknown param',
        ],
        self::ERR_OAUTH2_CODE => [
            'status' => 400,
            'errno' => 105,
            'msg' => 'error oauth2.0 code',
        ],
        self::ERR_UNAUTHORIZED => [
            'status' => 401,
            'errno' => 121,
            'msg' => 'login timeout',
        ],
        self::ERR_INVALID_CLIENT_IP => [
            'status' => 401,
            'errno' => 122,
            'msg' => 'request client ip does not exist in ip whitelist config',
        ],
        self::ERR_NO_PERMISSION => [
            'status' => 403,
            'errno' => 141,
            'msg' => 'permission denied or insufficient permissions',
        ],
        self::ERR_API_NOT_FOUND => [
            'status' => 404,
            'errno' => 161,
            'msg' => 'api not found',
        ],
        self::ERR_SYSTEM => [
            'status' => 500,
            'errno' => 201,
            'msg' => 'system error',
        ],
        self::ERR_SYS_DATABASE => [
            'status' => 500,
            'errno' => 202,
            'msg' => 'database error',
        ],
        self::ERR_NETWORK => [
            'status' => 500,
            'errno' => 203,
            'msg' => 'network can not connect to the data server',
        ],
        self::ERR_DATA_RESPONSE => [
            'status' => 500,
            'errno' => 204,
            'msg' => 'data server response error',
        ],
        self::ERR_DATA_SERVER_UNAVAILABLE => [
            'status' => 503,
            'errno' => 221,
            'msg' => 'data server unavailable',
        ],
    ];

    public static function getErr($errno)
    {
        if (!array_key_exists($errno, self::$errors)) {
            return;
        }

        return self::$errors[$errno];
    }
}
