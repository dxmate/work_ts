<?php
/**
 * AdapterUtil
 *
 * @author chencheng0312@thundersoft.com
 */

namespace Module\common;

use Module\common\config\AdapterParamKeys;
use Module\common\exception\AdapterException;
use Module\common\exception\ParameterException;

class AdapterUtil
{
    /**
     * check necessary params.
     *
     * @param array $params
     *
     * @throws ParameterException
     */
    public static function checkNecessaryParams(array $params)
    {
        $errorFlag = true;
        $dateKeyExists = array_key_exists(AdapterParamKeys::START_DATE, $params) && array_key_exists(AdapterParamKeys::END_DATE, $params);
        $weekKeyExists = array_key_exists(AdapterParamKeys::START_WEEK, $params) && array_key_exists(AdapterParamKeys::END_WEEK, $params);
        if ($dateKeyExists) {
            if (preg_match('/^\d{4}\-\d{1,2}\-\d{1,2}$/i', $params[AdapterParamKeys::START_DATE]) && preg_match('/^\d{4}\-\d{1,2}\-\d{1,2}$/i', $params[AdapterParamKeys::END_DATE])) {
                $errorFlag = false;
            }
        } elseif ($weekKeyExists) {
            if (preg_match('/^[0-55]{1,2}$/i', $params[AdapterParamKeys::START_WEEK]) && preg_match('/^[0-55]{1,2}$/i', $params[AdapterParamKeys::END_WEEK])) {
                $errorFlag = false;
            }
        }
        if ($errorFlag) {
            throw new AdapterException(null, ErrorNo::ERR_MISSING_PARAM);
        }
    }

    /**
     * 获取返回数据结果.
     *
     * @param string $dataFormat
     * @param string $data
     * @param array  $csvHeader
     * @param string $csvFileName
     *
     * @return array
     *
     * @throws AdapterException
     */
    public static function getAdapterResponseData(string $dataFormat, string $data, array $csvHeader = [], string $csvFileName = '')
    {
        $result = array(
            'format' => $dataFormat,
        );
        if ($dataFormat == AdapterParamKeys::FORMAT_CSV) {
            $result['data'] = self::makeCsvContent($data, $csvHeader);
            $result['fileName'] = $csvFileName;
        } else {
            // test the data is json format
            $jsonArray = json_decode($data, true);
            if (!is_null($jsonArray)) {
                $result['data'] = $jsonArray;
            } else {
                throw new AdapterException(null, ErrorNo::ERR_DATA_RESPONSE);
            }
        }

        return $result;
    }

    /**
     * 生成csv文件内容.
     *
     * @param string $csvBody
     * @param array  $csvHeader
     *
     * @return string
     */
    private static function makeCsvContent(string $csvBody, array $csvHeader = [])
    {
        $header = implode(',', $csvHeader)."\r";

        return $header.$csvBody;
    }

    /**
     * 生成可用于合并的csv data
     * @param string $data
     * 
     * @return string
     */
    public static function formatCsvDataForConbine(string $data)
    {
        $result = '';
        if (!empty($data)) {
            $dataArr = explode("\r", $data);
            for ($i = 0; $i < count($dataArr); $i++) {
                if (!empty($dataArr[$i])) {
                    $dataArr[$i] = explode(',', $dataArr[$i])[1];
                }
            }
            $result = implode("\r", $dataArr);
        }
        return $result;
    }

    /**
     * 合并2个csv data
     * @param string $data1
     * @param string $data2
     * 
     * @return string
     */
    public static function conbineTwoCsv(string $data1, string $data2) {
        $result = '';
        if (!empty($data1) && !empty($data2)) {
            $data1Arr = explode("\r", $data1);
            $data2Arr = explode("\r", $data2);
            $count = count($data1Arr) > count($data2Arr) ? count($data2Arr) : count($data1Arr);
            for ($i = 0; $i < $count; $i++) {
                $data1Arr[$i] = $data1Arr[$i] . ',' . $data2Arr[$i];
            }
            $result = implode("\r", $data1Arr);
        }
        return $result;
    }
}
