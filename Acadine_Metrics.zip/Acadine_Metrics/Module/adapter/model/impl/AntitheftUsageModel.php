<?php
/**
 * AntitheftUsageModel
 * Antitheft usage 数据模型
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\model\impl;

use Core\common\HttpClient;
use Core\common\HttpCode;
use Core\common\Singleton;
use Module\adapter\model\IAntitheftUsageModel;
use Module\common\config\AdapterParamKeys;
use Module\common\config\ApiUriConfig;
use Module\common\ErrorNo;
use Module\common\exception\AdapterException;

/**
 * this class is data access object for antitheft usage.
 */
class AntitheftUsageModel extends Singleton implements IAntitheftUsageModel
{
    /**
     * @return \Module\adapter\model\impl\AntitheftUsageModel
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\adapter\model\IAntitheftUsageModel::getEnabledSum()
     */
    public function getEnabledSum(string $startDate, string $endDate, string $format = '', string $device = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::AT_V1_ENABLED_SUM), true, $startDate, $endDate, $format, $device);

        return $result;
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\adapter\model\IAntitheftUsageModel::getLockDaily()
     */
    public function getLockDaily(string $startDate, string $endDate, string $format = '', string $device = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::AT_V1_LOCK_DAILY), true, $startDate, $endDate, $format, $device);

        return $result;
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\adapter\model\IAntitheftUsageModel::getWipeDaily()
     */
    public function getWipeDaily(string $startDate, string $endDate, string $format = '', string $device = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::AT_V1_WIPE_DAILY), true, $startDate, $endDate, $format, $device);

        return $result;
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\adapter\model\IAntitheftUsageModel::getDeviceOptions()
     */
    public function getDeviceOptions()
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::AT_V1_DEVICE_OPTIONS), false);

        return $result;
    }

    /**
     * this function is used for get data from url.
     *
     * @param string $url
     * @param bool   $hasParams
     * @param string $startParams
     * @param string $endParams
     * @param string $format
     * @param string $device
     *
     * @return string data from url
     */
    private function getUrlData(string $url, bool $hasParams, string $startParams = '', String $endParams = '', string $format = '', string $device = '')
    {
        $params = array();
        if ($hasParams) {
            $params = $this->getParams($startParams, $endParams, $format, $device);
        }
        $httpResponse = HttpClient::getInstance()->get($url, $params);
        $httpStatus = $httpResponse->getStatus();
        if ($httpStatus == HttpCode::HTTP_SUCCESS) {
            $result = $httpResponse->getBody();
        } else {
            throw new AdapterException(null, ErrorNo::ERR_DATA_RESPONSE);
        }

        return $result;
    }

    /**
     * this function is used for apply data source.
     *
     * @param string $startParams
     * @param string $endParams
     * @param string $format
     * @param string $device
     *
     * @return array
     */
    private function getParams(string $startParams, string $endParams, string $format = '', string $device = '')
    {
        $startParamsKey = AdapterParamKeys::START_DATE;
        $endParamsKey = AdapterParamKeys::END_DATE;
        $result = array(
            $startParamsKey => $startParams,
            $endParamsKey => $endParams,
        );
        if ($format == AdapterParamKeys::FORMAT_CSV) {
            $result[AdapterParamKeys::FORMAT] = $format;
        }
        if ($device != '' && $device != 'null') {
            $result[AdapterParamKeys::DEVICE] = ($device == 'empty' ? '' : str_replace('empty', '', $device));
        }

        return $result;
    }
}
