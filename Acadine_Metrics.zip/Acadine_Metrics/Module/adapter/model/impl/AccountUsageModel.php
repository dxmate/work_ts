<?php
/**
 * AccountUsageModel
 * Account usage 数据模型
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\model\impl;

use Core\common\HttpClient;
use Core\common\HttpCode;
use Core\common\Singleton;
use Module\adapter\model\IAccountUsageModel;
use Module\common\config\AdapterParamKeys;
use Module\common\config\ApiUriConfig;
use Module\common\ErrorNo;
use Module\common\exception\AdapterException;

/**
 * This class is data access object for account usage.
 */
class AccountUsageModel extends Singleton implements IAccountUsageModel
{
    /**
     * @return \Module\adapter\model\impl\AccountUsageModel
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * @see \Module\adapter\model\IAccountUsageModel::getValidatedusersDaily()
     */
    public function getValidatedusersDaily(string $startDate, string $endDate, string $format = '', string $referer = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_DAILY), false, $startDate, $endDate, $format, $referer, '');

        return $result;
    }

    /**
     * @see \Module\adapter\model\IAccountUsageModel::getValidatedusersTotal()
     */
    public function getValidatedusersTotal(string $startDate, string $endDate, string $format = '', string $referer = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::H5A_V1_VALIDATEDUSERS_TOTAL), false, $startDate, $endDate, $format, $referer, '');

        return $result;
    }

    /**
     * @see \Module\authority\model\IAccountUsageModel::getActiveusersDaily()
     */
    public function getActiveusersDaily(string $startDate, string $endDate, string $format = '', string $device = '', string $product = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_DAILY), false, $startDate, $endDate, $format, '', '', $device, $product);

        return $result;
    }

    /**
     * @see \Module\authority\model\IAccountUsageModel::getActiveusersWeekly()
     */
    public function getActiveusersWeekly(string $startDate, string $endDate, string $format = '', string $device = '', string $product = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::H5A_V1_ACTIVEUSERS_WEEKLY), false, $startDate, $endDate, $format, '', '', $device, $product);

        return $result;
    }

    /**
     * @see \Module\authority\model\IAccountUsageModel::getOptions()
     */
    public function getOptions(string $params)
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::H5A_V1_OPTIONS), false, '', '', '', '', $params, '', '');

        return $result;
    }

    /**
     * To get data from url.
     *
     * @param string $url
     * @param bool   $isWeekParams
     * @param string $startParams
     * @param string $endParams
     * @param string $format
     * @param string $referer
     * @param string $params
     * @param string $device
     * @param string $product
     *
     * @return string data from url
     */
    private function getUrlData(string $url, bool $isWeekParams, string $startParams = '', string $endParams = '', string $format = '', string $referer = '', string $params = '', string $device = '', string $product = '')
    {
        $urlparams = array();
        $urlparams = $this->getParams($isWeekParams, $startParams, $endParams, $format, $referer, $params, $device, $product);
        $httpResponse = HttpClient::getInstance()->get($url, $urlparams);
        $httpStatus = $httpResponse->getStatus();
        if ($httpStatus == HttpCode::HTTP_SUCCESS) {
            $result = $httpResponse->getBody();
        } else {
            throw new AdapterException(null, ErrorNo::ERR_DATA_RESPONSE);
        }

        return $result;
    }

    /**
     * To make params for accountUsage.
     *
     * @param bool   $isWeekParams
     * @param string $startParams
     * @param string $endParams
     * @param string $format
     * @param string $referer
     * @param string $params
     * @param string $device
     * @param string $product
     *
     * @return array
     */
    private function getParams(bool $isWeekParams, string $startParams = '', string $endParams = '', string $format = '', string $referer = '', string $params = '', string $device = '', string $product = '')
    {
        $startParamsKey = AdapterParamKeys::START_DATE;
        $endParamsKey = AdapterParamKeys::END_DATE;
        $result = array();
        if ($isWeekParams) {
            $startParamsKey = AdapterParamKeys::START_WEEK;
            $endParamsKey = AdapterParamKeys::END_WEEK;
        }
        if ($startParams != '' && $startParams != 'null') {
            $result[$startParamsKey] = $startParams;
        }
        if ($endParams != '' && $endParams != 'null') {
            $result[$endParamsKey] = $endParams;
        }
        if ($format == AdapterParamKeys::FORMAT_CSV) {
            $result[AdapterParamKeys::FORMAT] = $format;
        }
        if ($referer != '' && $referer != 'null') {
            $result[AdapterParamKeys::REFERER] = ($referer == 'empty' ? '' : str_replace('empty', '', $referer));
        }
        if ($params != '' && $params != 'null') {
            $result[AdapterParamKeys::PARAMS] = ($params == 'empty' ? '' : str_replace('empty', '', $params));
        }
        if ($device != '' && $device != 'null') {
            $result[AdapterParamKeys::DEVICE] = ($device == 'empty' ? '' : str_replace('empty', '', $device));
        }
        if ($product != '' && $product != 'null') {
            $result[AdapterParamKeys::PRODUCT] = ($product == 'empty' ? '' : str_replace('empty', '', $product));
        }

        return $result;
    }
}
