<?php
/**
 * TelemetryModel
 * Telemetry 数据模型
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\model\impl;

use Core\common\HttpClient;
use Core\common\HttpCode;
use Core\common\Singleton;
use Module\common\config\AdapterParamKeys;
use Module\common\config\ApiUriConfig;
use Module\common\ErrorNo;
use Module\common\exception\AdapterException;
use Module\adapter\model\ITelemetryModel;

/**
 * this class is data access object for telemetry.
 */
class TelemetryModel extends Singleton implements ITelemetryModel
{
    /**
     * @return \Module\adapter\model\impl\TelemetryModel
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * @see \Module\adapter\model\ITelemetryModel::getFtuSum()
     */
    public function getFtuSum(string $startDate, string $endDate, string $os = '', string $device = '', string $operator = '', string $country = '', string $chipset = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_SUM), false, '', $startDate, $endDate, $os, $device, $operator, $country, $chipset, '');

        return $result;
    }

    /**
     * @see \Module\adapter\model\ITelemetryModel::getFtuDaily()
     */
    public function getFtuDaily(string $startDate, string $endDate, string $format = '', string $os = '', string $device = '', string $operator = '', string $country = '', string $chipset = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_DAILY), true, $format, $startDate, $endDate, $os, $device, $operator, $country, $chipset, '');

        return $result;
    }

    /**
     * @see \Module\adapter\model\ITelemetryModel::getFtuOptions()
     */
    public function getFtuOptions(string $params = '')
    {
        $result = $this->getUrlData(ApiUriConfig::get(ApiUriConfig::TL_V1_FTU_OPTIONS), false, '', '', '', '', '', '', '', '', $params);

        return $result;
    }

    /**
     * To get data from url.
     *
     * @param string $url
     * @param bool   $hasformat
     * @param string $format
     * @param string $startParams
     * @param string $endParams
     * @param string $os
     * @param string $device
     * @param string $operator
     * @param string $country
     * @param string $chipset
     * @param string $params
     *
     * @return string data from url
     *
     * @throws AdapterException
     */
    private function getUrlData(string $url, bool $hasformat, string $format, string $startParams = '', string $endParams = '', string $os = '', string $device = '', string $operator = '', string $country = '', string $chipset = '', string $params = '')
    {
        $urlparams = array();
        $urlparams = $this->getParams($startParams, $endParams, $hasformat, $format, $os, $device, $operator, $country, $chipset, $params);
        $httpResponse = HttpClient::getInstance()->get($url, $urlparams);
        $httpStatus = $httpResponse->getStatus();
        if ($httpStatus == HttpCode::HTTP_SUCCESS) {
            $result = $httpResponse->getBody();
        } else {
            throw new AdapterException(null, ErrorNo::ERR_DATA_RESPONSE);
        }

        return $result;
    }

    /**
     * To make params for telemetry.
     *
     * @param string $startParams
     * @param string $endParams
     * @param bool   $hasformat
     * @param string $format
     * @param string $os
     * @param string $device
     * @param string $operator
     * @param string $country
     * @param string $chipset
     * @param string $params
     *
     * @return array
     */
    private function getParams(string $startParams = '', string $endParams = '', bool $hasformat, string $format = '', string $os = '', string $device = '', string $operator = '', string $country = '', string $chipset = '', string $params = '')
    {
        $startParamsKey = AdapterParamKeys::START_DATE;
        $endParamsKey = AdapterParamKeys::END_DATE;
        $result = array();
        if ($startParams != '' && $startParams != 'null') {
            $result[$startParamsKey] = $startParams;
        }
        if ($endParams != '' && $endParams != 'null') {
            $result[$endParamsKey] = $endParams;
        }
        if ($hasformat) {
            if ($format == AdapterParamKeys::FORMAT_CSV) {
                $result[AdapterParamKeys::FORMAT] = $format;
            }
        }
        if ($os != '' && $os != 'null') {
            $result[AdapterParamKeys::OPERATOR_SYS] = ($os == 'empty' ? '' : str_replace('empty', '', $os));
        }
        if ($device != '' && $device != 'null') {
            $result[AdapterParamKeys::DEVICE] = ($device == 'empty' ? '' : str_replace('empty', '', $device));
        }
        if ($operator != '' && $operator != 'null') {
            $result[AdapterParamKeys::OPERATOR] = ($operator == 'empty' ? '' : str_replace('empty', '', $operator));
        }
        if ($country != '' && $country != 'null') {
            $result[AdapterParamKeys::COUNTRY] = ($country == 'empty' ? '' : str_replace('empty', '', $country));
        }
        if ($chipset != '' && $chipset != 'null') {
            $result[AdapterParamKeys::CHIPSET] = ($chipset == 'empty' ? '' : str_replace('empty', '', $chipset));
        }
        if ($params != '' && $params != 'null') {
            $result[AdapterParamKeys::PARAMS] = ($params == 'empty' ? '' : str_replace('empty', '', $params));
        }

        return $result;
    }
}
