<?php
/**
 * IAntitheftUsageModel
 * Antitheft usage 数据模型接口
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\model;

/**
 * the interface of antitheft usage model.
 */
interface IAntitheftUsageModel
{
    /**
     * get data from the out interface /antitheftusage/v1/enabled/sum.
     *
     * @param string $startDate
     *                          start date,default is current date
     * @param string $endDate
     *                          end date,default is the latest 3 months from current date
     * @param string $format
     *                          result format,default is json
     * @param string $device
     *                          device info
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getEnabledSum(string $startDate, string $endDate, string $format = '', string $device = '');

    /**
     * get data from the out interface /antitheftusage/v1/lock/daily.
     *
     * @param string $startDate
     *                          start date,default is current date
     * @param string $endDate
     *                          end date,default is the latest 3 months from current date
     * @param string $format
     *                          result format,default is json
     * @param string $device
     *                          device info
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getLockDaily(string $startDate, string $endDate, string $format = '', string $device = '');

    /**
     * get data from the out interface /antitheftusage/v1/wipe/daily.
     *
     * @param string $startDate
     *                          start date,default is current date
     * @param string $endDate
     *                          end date,default is the latest 3 months from current date
     * @param string $format
     *                          result format,default is json
     * @param string $device
     *                          device info
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getWipeDaily(string $startDate, string $endDate, string $format = '', string $device = '');

    /**
     * get data from the out interface /antitheftusage/v1/device/options.
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getDeviceOptions();
}
