<?php
/**
 * IAccountUsageModel
 * Account usage 数据模型接口
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\model;

/**
 * account usage model interface.
 */
interface IAccountUsageModel
{
    /**
     * get data from out interface /accountusage/v1/validatedusers/daily.
     *
     * @param string $startDate
     *                          start date
     * @param string $endDate
     *                          end date
     * @param string $format
     *                          optional, result format which is json by default, csv is the another option
     * @param string referer
     *                              optional, referer list separated by comma
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getValidatedusersDaily(string $startDate, string $endDate, string $format = '', string $referer = '');

    /**
     * get data from out interface /accountusage/v1/validatedusers/total.
     *
     * @param string $startDate
     *                          start date
     * @param string $endDate
     *                          end date
     * @param string $format
     *                          optional, result format which is json by default, csv is the another option
     * @param string referer
     *                              optional, referer list separated by comma
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getValidatedusersTotal(string $startDate, string $endDate, string $format = '', string $referer = '');

    /**
     * get data from out interface /accountusage/v1/activeusers/daily.
     *
     * @param string $startDate
     *                          start date
     * @param string $endDate
     *                          end date
     * @param string $format
     *                          optional, result format which is json by default, csv is the another option
     * @param string $device
     *                              optional, device list separated by comma
     * @param string $product
     *                              optional, product list separated by comma
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getActiveusersDaily(string $startDate, string $endDate, string $format = '', string $device = '', string $product = '');

    /**
     * get data from out interface /accountusage/v1/activeusers/weekly.
     *
     * @param string $startDate
     *                          start date
     * @param string $endDate
     *                          end date
     * @param string $format
     *                          optional, result format which is json by default, csv is the another option
     * @param string $device
     *                              optional, device list separated by comma
     * @param string $product
     *                              optional, product list separated by comma
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getActiveusersWeekly(string $startDate, string $endDate, string $format = '', string $device = '', string $product = '');

    /**
     * get data from out interface /accountusage/v1/options.
     *
     * @param string $params
     *                       param list separated by comma
     *
     * @throws AdapterException
     *
     * @return mixed data from out-interface
     */
    public function getOptions(string $params);
}
