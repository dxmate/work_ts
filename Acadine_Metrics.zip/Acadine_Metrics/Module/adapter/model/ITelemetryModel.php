<?php
/**
 * ITelemetryModel
 * Telemetry 数据模型接口
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\model;

interface ITelemetryModel
{
    /**
     * get data from the out interface telemetry/v1/ftu/sum.
     *
     * @param string $startDate
     *                          start date,default is current date
     * @param string $endDate
     *                          end date,default is the latest 3 months from current date
     * @param string $os
     *                          os list
     * @param string $device
     *                          device list
     * @param string $operator
     *                          operator list
     * @param string $country
     *                          country list
     * @param string $chipset
     *                          chipset list
     *
     * @return mixed
     */
    public function getFtuSum(string $startDate, string $endDate, string $os = '', string $device = '', string $operator = '', string $country = '', string $chipset = '');

    /**
     * get data from the out interface  telemetry/v1/ftu/daily.
     *
     * @param string $startDate
     *                          start date,default is current date
     * @param string $endDate
     *                          end date,default is the latest 3 months from current date
     * @param string $format
     *                          result format,default is json
     * @param string $os
     *                          os list
     * @param string $device
     *                          device list
     * @param string $operator
     *                          operator list
     * @param string $country
     *                          country list
     * @param string $chipset
     *                          chipset list
     *
     * @return mixed
     */
    public function getFtuDaily(string $startDate, string $endDate, string $format = '', string $os = '', string $device = '', string $operator = '', string $country = '', string $chipset = '');

    /**
     * get data from the out interface  telemetry/v1/ftu/options.
     *
     * @param string $params
     *                       param list separated by comma
     *
     * @return mixed
     */
    public function getFtuOptions(string $params);
}
