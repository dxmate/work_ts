<?php
/**
 * TelemetryService
 * Telemetry 服务
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\service\impl;

use Core\common\Singleton;
use Module\common\AdapterUtil;
use Module\common\config\CsvHeaders;
use Module\common\config\AdapterParamKeys;
use Module\adapter\model\impl\TelemetryModel;
use Module\adapter\service\ITelemetryService;

/**
 * this class is implement of interface ITelemetryService.
 */
class TelemetryService extends Singleton implements ITelemetryService
{
    /**
     * @return \Module\adapter\service\impl\TelemetryService
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * @see \Module\adapter\service\ITelemetryService::getFtuSum()
     */
    public function getFtuSum($params)
    {
        $result = array();
        $res = $this->handleReceiveParams($params);
        $modelData = TelemetryModel::getInstance()->getFtuSum($res[AdapterParamKeys::START_DATE], $res[AdapterParamKeys::END_DATE], $res[AdapterParamKeys::OPERATOR_SYS], $res[AdapterParamKeys::DEVICE], $res[AdapterParamKeys::OPERATOR], $res[AdapterParamKeys::COUNTRY], $res[AdapterParamKeys::CHIPSET]);
        $result = AdapterUtil::getAdapterResponseData('', $modelData);

        return $result;
    }

    /**
     * @see \Module\adapter\service\ITelemetryService::getFtuDaily()
     */
    public function getFtuDaily($params)
    {
        $result = array();
        $res = $this->handleReceiveParams($params);
        $modelData = TelemetryModel::getInstance()->getFtuDaily($res[AdapterParamKeys::START_DATE], $res[AdapterParamKeys::END_DATE], $res[AdapterParamKeys::FORMAT], $res[AdapterParamKeys::OPERATOR_SYS], $res[AdapterParamKeys::DEVICE], $res[AdapterParamKeys::OPERATOR], $res[AdapterParamKeys::COUNTRY], $res[AdapterParamKeys::CHIPSET]);
        $csvFileName = 'daily_ftu_' . $res[AdapterParamKeys::START_DATE] . '_' . $res[AdapterParamKeys::END_DATE] . '.csv';
        $result = AdapterUtil::getAdapterResponseData($res[AdapterParamKeys::FORMAT], $modelData, CsvHeaders::TL_V1_FTU_DAILY, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\ITelemetryService::getFtuOptions()
     */
    public function getFtuOptions($params = '')
    {
        $result = array();
        if (is_array($params)) {
            $params = implode(',', $params);
        }
        $params = (is_null($params) || empty($params)) ? '' : $params;
        $modelData = TelemetryModel::getInstance()->getFtuOptions($params);
        $result = AdapterUtil::getAdapterResponseData('', $modelData);

        return $result;
    }

    /**
     * this function is used for handle the received params.
     *
     * @param array $params
     *
     * @return array
     */
    private function handleReceiveParams(array $params)
    {
        $res = array();
        AdapterUtil::checkNecessaryParams($params);
        $startDate = (new \DateTime($params[AdapterParamKeys::START_DATE]))->format('Y-m-d');
        $res[AdapterParamKeys::START_DATE] = $startDate;
        $endDate = (new \DateTime($params[AdapterParamKeys::END_DATE]))->format('Y-m-d');
        $res[AdapterParamKeys::END_DATE] = $endDate;
        $format = array_key_exists(AdapterParamKeys::FORMAT, $params) ? ($params[AdapterParamKeys::FORMAT] == AdapterParamKeys::FORMAT_CSV ? AdapterParamKeys::FORMAT_CSV : '') : '';
        $res[AdapterParamKeys::FORMAT] = $format;
        $os = array_key_exists(AdapterParamKeys::OPERATOR_SYS, $params) ? (is_null($params[AdapterParamKeys::OPERATOR_SYS]) || empty($params[AdapterParamKeys::OPERATOR_SYS]) ? '' : $params[AdapterParamKeys::OPERATOR_SYS]) : '';
        $res[AdapterParamKeys::OPERATOR_SYS] = $os;
        $device = array_key_exists(AdapterParamKeys::DEVICE, $params) ? (is_null($params[AdapterParamKeys::DEVICE]) || empty($params[AdapterParamKeys::DEVICE]) ? '' : $params[AdapterParamKeys::DEVICE]) : '';
        $res[AdapterParamKeys::DEVICE] = $device;
        $operator = array_key_exists(AdapterParamKeys::OPERATOR, $params) ? (is_null($params[AdapterParamKeys::OPERATOR]) || empty($params[AdapterParamKeys::OPERATOR]) ? '' : $params[AdapterParamKeys::OPERATOR]) : '';
        $res[AdapterParamKeys::OPERATOR] = $operator;
        $country = array_key_exists(AdapterParamKeys::COUNTRY, $params) ? (is_null($params[AdapterParamKeys::COUNTRY]) || empty($params[AdapterParamKeys::COUNTRY]) ? '' : $params[AdapterParamKeys::COUNTRY]) : '';
        $res[AdapterParamKeys::COUNTRY] = $country;
        $chipset = array_key_exists(AdapterParamKeys::CHIPSET, $params) ? (is_null($params[AdapterParamKeys::CHIPSET]) || empty($params[AdapterParamKeys::CHIPSET]) ? '' : $params[AdapterParamKeys::CHIPSET]) : '';
        $res[AdapterParamKeys::CHIPSET] = $chipset;

        return $res;
    }
}
