<?php
/**
 * AccountUsageService
 * Account Usge 服务
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\service\impl;

use Core\common\Singleton;
use Module\adapter\model\impl\AccountUsageModel;
use Module\adapter\service\IAccountUsageService;
use Module\common\AdapterUtil;
use Module\common\config\AdapterParamKeys;
use Module\common\config\CsvHeaders;

/**
 * This class is implement of interface IAccountUsageService.
 */
class AccountUsageService extends Singleton implements IAccountUsageService
{
    const START_WEEK_COUNT = 0;
    const END_WEEK_COUNT = 53;

    /**
     * @return \Module\adapter\service\impl\AccountUsageService
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * @see \Module\adapter\service\IAccountUsageService::getValidatedusersDaily()
     */
    public function getValidatedusersDaily($params)
    {
        $result = array();
        AdapterUtil::checkNecessaryParams($params);
        $startDate = (new \DateTime($params[AdapterParamKeys::START_DATE]))->format('Y-m-d');
        $endDate = (new \DateTime($params[AdapterParamKeys::END_DATE]))->format('Y-m-d');
        $format = array_key_exists(AdapterParamKeys::FORMAT, $params) ? ($params[AdapterParamKeys::FORMAT] == AdapterParamKeys::FORMAT_CSV ? AdapterParamKeys::FORMAT_CSV : '') : '';
        $referer = array_key_exists(AdapterParamKeys::REFERER, $params) ? $params[AdapterParamKeys::REFERER] : '';
        $modelData = AccountUsageModel::getInstance()->getValidatedusersDaily($startDate, $endDate, $format, $referer);
        $csvFileName = 'daily_validated_users_'.$startDate.'_'.$endDate.'.csv';
        $result = AdapterUtil::getAdapterResponseData($format, $modelData, CsvHeaders::H5A_V1_VALIDATEDUSERS_DAILY, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\IAccountUsageService::getValidatedusersTotal()
     */
    public function getValidatedusersTotal($params)
    {
        $result = array();
        $validatedusersDailyModelData = '';
        AdapterUtil::checkNecessaryParams($params);
        $startDate = (new \DateTime($params[AdapterParamKeys::START_DATE]))->format('Y-m-d');
        $endDate = (new \DateTime($params[AdapterParamKeys::END_DATE]))->format('Y-m-d');
        $format = array_key_exists(AdapterParamKeys::FORMAT, $params) ? ($params[AdapterParamKeys::FORMAT] == AdapterParamKeys::FORMAT_CSV ? AdapterParamKeys::FORMAT_CSV : '') : '';
        $referer = array_key_exists(AdapterParamKeys::REFERER, $params) ? $params[AdapterParamKeys::REFERER] : '';
        $modelData = AccountUsageModel::getInstance()->getValidatedusersTotal($startDate, $endDate, $format, $referer);
        $csvFileName = 'total_validated_users_' . $startDate . '_' . $endDate . '.csv';
        $result = AdapterUtil::getAdapterResponseData($format, $modelData, CsvHeaders::H5A_V1_VALIDATEDUSERS_TOTAL, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\IAccountUsageService::getActiveusersDaily()
     */
    public function getActiveusersDaily($params)
    {
        $result = array();
        AdapterUtil::checkNecessaryParams($params);
        $startDate = (new \DateTime($params[AdapterParamKeys::START_DATE]))->format('Y-m-d');
        $endDate = (new \DateTime($params[AdapterParamKeys::END_DATE]))->format('Y-m-d');
        $format = array_key_exists(AdapterParamKeys::FORMAT, $params) ? ($params[AdapterParamKeys::FORMAT] == AdapterParamKeys::FORMAT_CSV ? AdapterParamKeys::FORMAT_CSV : '') : '';
        $device = array_key_exists(AdapterParamKeys::DEVICE, $params) ? $params[AdapterParamKeys::DEVICE] : '';
        $product = array_key_exists(AdapterParamKeys::PRODUCT, $params) ? $params[AdapterParamKeys::PRODUCT] : '';
        $modelData = AccountUsageModel::getInstance()->getActiveusersDaily($startDate, $endDate, $format, $device, $product);
        $csvFileName = 'daily_active_users_'.$startDate.'_'.$endDate.'.csv';
        $result = AdapterUtil::getAdapterResponseData($format, $modelData, CsvHeaders::H5A_V1_ACTIVEUSERS_DAILY, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\IAccountUsageService::getActiveusersWeekly()
     */
    public function getActiveusersWeekly($params)
    {
        $result = array();
        $startDate = $params[AdapterParamKeys::START_DATE];
        $endDate = $params[AdapterParamKeys::END_DATE];
        $format = array_key_exists(AdapterParamKeys::FORMAT, $params) ? ($params[AdapterParamKeys::FORMAT] == AdapterParamKeys::FORMAT_CSV ? AdapterParamKeys::FORMAT_CSV : '') : '';
        $device = array_key_exists(AdapterParamKeys::DEVICE, $params) ? $params[AdapterParamKeys::DEVICE] : '';
        $product = array_key_exists(AdapterParamKeys::PRODUCT, $params) ? $params[AdapterParamKeys::PRODUCT] : '';
        $modelData = AccountUsageModel::getInstance()->getActiveusersWeekly($startDate, $endDate, $format, $device, $product);
        $csvFileName = 'weekly_active_users_' . $startDate . '_' . $endDate . '.csv';
        $result = AdapterUtil::getAdapterResponseData($format, $modelData, CsvHeaders::H5A_V1_ACTIVEUSERS_WEEKLY, $csvFileName);
        return $result;
    }

    /**
     * @see \Module\adapter\service\IAccountUsageService::getOptions()
     */
    public function getOptions($params)
    {
        $result = array();
        if ($params && is_array($params)) {
            $params = implode(',', $params);
        }
        $modelData = AccountUsageModel::getInstance()->getOptions($params);
        $result = AdapterUtil::getAdapterResponseData('', $modelData);

        return $result;
    }
}
