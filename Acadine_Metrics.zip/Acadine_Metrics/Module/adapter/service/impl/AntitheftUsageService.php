<?php
/**
 * AntitheftUsageService
 * Antitheft Usge 服务
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\service\impl;

use Core\common\Singleton;
use Module\common\AdapterUtil;
use Module\common\config\CsvHeaders;
use Module\common\config\AdapterParamKeys;
use Module\adapter\model\impl\AntitheftUsageModel;
use Module\adapter\service\IAntitheftUsageService;

/**
 * this class is implement of interface IAntitheftUsageService.
 */
class AntitheftUsageService extends Singleton implements IAntitheftUsageService
{
    /**
     * @return \Module\adapter\service\impl\AntitheftUsageService
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * @see \Module\adapter\service\IAntitheftUsageService::getEnabledSum()
     */
    public function getEnabledSum($params)
    {
        $result = array();
        $res = $this->handleReceiveParams($params);
        $modelData = AntitheftUsageModel::getInstance()->getEnabledSum($res[AdapterParamKeys::START_DATE], $res[AdapterParamKeys::END_DATE], $res[AdapterParamKeys::FORMAT], $res[AdapterParamKeys::DEVICE]);
        $csvFileName = 'antitheft_enabled_'.$res[AdapterParamKeys::START_DATE].'_'.$res[AdapterParamKeys::END_DATE].'.csv';
        $result = AdapterUtil::getAdapterResponseData($res[AdapterParamKeys::FORMAT], $modelData, CsvHeaders::A_V1_ENABLEDUSERS_SUM, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\IAntitheftUsageService::getLockDaily()
     */
    public function getLockDaily($params)
    {
        $result = array();
        $res = $this->handleReceiveParams($params);
        $modelData = AntitheftUsageModel::getInstance()->getLockDaily($res[AdapterParamKeys::START_DATE], $res[AdapterParamKeys::END_DATE], $res[AdapterParamKeys::FORMAT], $res[AdapterParamKeys::DEVICE]);
        $csvFileName = 'antitheft_lock_daily_'.$res[AdapterParamKeys::START_DATE].'_'.$res[AdapterParamKeys::END_DATE].'.csv';
        $result = AdapterUtil::getAdapterResponseData($res[AdapterParamKeys::FORMAT], $modelData, CsvHeaders::A_V1_LOCKUSERS_DAILY, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\IAntitheftUsageService::getWipeDaily()
     */
    public function getWipeDaily($params)
    {
        $result = array();
        $res = $this->handleReceiveParams($params);
        $modelData = AntitheftUsageModel::getInstance()->getWipeDaily($res[AdapterParamKeys::START_DATE], $res[AdapterParamKeys::END_DATE], $res[AdapterParamKeys::FORMAT], $res[AdapterParamKeys::DEVICE]);
        $csvFileName = 'antitheft_wipe_daily_'.$res[AdapterParamKeys::START_DATE].'_'.$res[AdapterParamKeys::END_DATE].'.csv';
        $result = AdapterUtil::getAdapterResponseData($res[AdapterParamKeys::FORMAT], $modelData, CsvHeaders::A_V1_WIPEUSERS_DAILY, $csvFileName);

        return $result;
    }

    /**
     * @see \Module\adapter\service\IAntitheftUsageService::getDeviceOptions()
     */
    public function getDeviceOptions()
    {
        $result = array();
        $modelData = AntitheftUsageModel::getInstance()->getDeviceOptions();
        $result = AdapterUtil::getAdapterResponseData('', $modelData);

        return $result;
    }

    /**
     * this function is used for handle the received params.
     *
     * @param array $params
     */
    private function handleReceiveParams(array $params)
    {
        $res = array();
        AdapterUtil::checkNecessaryParams($params);
        $startDate = (new \DateTime($params[AdapterParamKeys::START_DATE]))->format('Y-m-d');
        $res[AdapterParamKeys::START_DATE] = $startDate;
        $endDate = (new \DateTime($params[AdapterParamKeys::END_DATE]))->format('Y-m-d');
        $res[AdapterParamKeys::END_DATE] = $endDate;
        $format = array_key_exists(AdapterParamKeys::FORMAT, $params) ? ($params[AdapterParamKeys::FORMAT] == AdapterParamKeys::FORMAT_CSV ? AdapterParamKeys::FORMAT_CSV : '') : '';
        $res[AdapterParamKeys::FORMAT] = $format;
        $device = array_key_exists(AdapterParamKeys::DEVICE, $params) ? (is_null($params[AdapterParamKeys::DEVICE]) || empty($params[AdapterParamKeys::DEVICE]) ? '' : $params[AdapterParamKeys::DEVICE]) : '';
        $res[AdapterParamKeys::DEVICE] = $device;

        return $res;
    }
}
