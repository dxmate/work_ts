<?php
/**
 * ITelemetryService
 * Telemetry 服务接口
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\service;

use Module\common\exception\AdapterException;

/**
 * Interface ITelemetryService.
 */
interface ITelemetryService
{
    /**
     * this service is used for get ftu users sum.
     *
     * @param array $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getFtuSum($params);

    /**
     * this service is used for get ftu users daily.
     *
     * @param array $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getFtuDaily($params);

    /**
     * this service is used for get ftu options.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed
     */
    public function getFtuOptions($params);
}
