<?php
/**
 * IAntitheftUsageService
 * Antitheft Usge 服务接口
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\service;

/**
 * antitheftusage service interface.
 */
interface IAntitheftUsageService
{
    /**
     * this service is used for get enable users sum.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getEnabledSum($params);

    /**
     * this service is used for get data of lock users daily.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getLockDaily($params);

    /**
     * this service is used for get data of wipe users daily.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getWipeDaily($params);

    /**
     * this service is used for get data of device options.
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getDeviceOptions();
}
