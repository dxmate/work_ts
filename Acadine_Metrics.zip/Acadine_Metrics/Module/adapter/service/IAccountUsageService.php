<?php
/**
 * IAccountUsageService
 * Account Usge 服务接口
 * @author chencheng0312@thundersoft.com
 */

namespace Module\adapter\service;

/**
 * accountUsage service interface.
 */
interface IAccountUsageService
{
    /**
     * this service is for getting data of validated users daily.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getValidatedusersDaily($params);

    /**
     * this service is for getting data of validated users total.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getValidatedusersTotal($params);

    /**
     * this service is for getting data of active users daily.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getActiveusersDaily($params);

    /**
     * this service is for getting data of active users weekly.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getActiveusersWeekly($params);

    /**
     * this service is for getting data of referers.
     *
     * @param string $params
     *
     * @throws AdapterException
     *
     * @return mixed data from service
     */
    public function getOptions($params);
}
