<?php
/**
 * Mock
 * 测试数据接口定义
 * @author fengfei1124@thundersoft.com
 */

namespace Module\v1\mock;

use Core\common\HttpClient;
use Core\lib\Config;
use Core\common\HttpResponse;
use Module\User\model\impl\UserModel;
use Module\User\service\impl\UserService;
use Module\User\vo\LoginUser;

/**
 * mock data when dev or test.
 */
class Mock
{
    private static $apiMockResponses = [];

    private static $mockLoginUserToken = 'login-user-token';

    /**
     * mock login user.
     *
     * @param \Slim\Slim $app
     *                        Slim app
     */
    public static function mockLoginUser(\Slim\Slim $app)
    {
        $app->request->cookies->set('token', self::$mockLoginUserToken);
        $user = new LoginUser();
        $user->accSys = 'office365';
        $user->org = 'acadine';
        $user->name = 'joe';
        $user->oid = '1001';
        $user->email = 'joe@acadine.com';
        UserModel::getInstance()->addLoginUser($user, self::$mockLoginUserToken, UserService::EXPIRE_TIME);
    }

    /**
     * mock server http api responses.
     */
    public static function morkServerHttpApiData()
    {
        $dataPath = APP_PATH.'Module/v1/mock/data/';
        $dataFiles = glob($dataPath.'*.json');
        foreach ($dataFiles as $dataFile) {
            $content = file_get_contents($dataFile);
            $content = str_replace('API_HOST_ACCOUNT', Config::get('API_HOST_ACCOUNT'), $content);
            $mock = json_decode($content, true);
            if (!is_null($mock)) {
                self::$apiMockResponses = array_merge(self::$apiMockResponses, $mock);
            }
        }
        foreach (self::$apiMockResponses as $url => $apiMockResponse) {
            HttpClient::mock([
                $url => new HttpResponse(json_encode($apiMockResponse)),
            ]);
        }

        return self::$apiMockResponses;
    }

}
