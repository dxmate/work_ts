<?php
/**
 * User
 * 定义用户接口，登出，获取用户信息
 * @author maxc1216@thundersoft.com
 */

namespace Module\v1\controller;

use Module\common\controller\ApiBaseController;
use Module\User\service\impl\UserService;

class User extends ApiBaseController
{
    const OFFICE365_LOGOUT_URL = 'https://login.microsoftonline.com/common/oauth2/logout';

    /**
     * logout.
     */
    public function logout()
    {
        $token = $this->app->getCookie('token');
        $this->app->response->cookies->remove('token');
        UserService::getInstance()->logout($token);
        $this->app->response->setBody(json_encode([
            'status' => 200,
            'errno' => 0,
            'info' => self::OFFICE365_LOGOUT_URL,
        ]));
    }

    /**
     * get user info.
     */
    public function info()
    {
        $this->responseJson('', [
            'name' => $this->loginUser->name,
            'email' => $this->loginUser->email,
        ]);
    }
}
