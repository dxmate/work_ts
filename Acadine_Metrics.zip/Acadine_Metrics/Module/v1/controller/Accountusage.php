<?php
/**
 * Accountusage
 * account usage 控制器，定义 account usage 的各种接口
 * @author wanghu1209@thundersoft.com
 */

namespace Module\v1\controller;

use Module\adapter\service\impl\AccountUsageService;
use Module\common\config\AdapterParamKeys;
use Module\common\controller\ApiBaseController;

class Accountusage extends ApiBaseController
{

    /**
     * controller for accountusage of validatedusersdaily
     *
     * @access public
     */
    public function validatedusersdaily()
    {
        $serviceData = AccountUsageService::getInstance()->getValidatedusersDaily($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        } else {
            $this->responseJson('validateduserdaily', $serviceData['data']);
        }
    }

    /**
     * controller for accountusage of validateduserstotal
     *
     * @access public
     */
    public function validateduserstotal()
    {
        $serviceData = AccountUsageService::getInstance()->getValidatedusersTotal($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        }else {
            $this->responseJson('validatedusertotal', $serviceData['data']);
        }
    }

    /**
     * controller for accountusage of activeusersdaily
     *
     * @access public
     */
    public function activeusersdaily()
    {
        $serviceData = AccountUsageService::getInstance()->getActiveusersDaily($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        } else {
            $this->responseJson('activeuserdaily', $serviceData['data']);
        }
    }

    /**
     * controller for accountusage of activeusersweekly
     *
     * @access public
     */
    public function activeusersweekly()
    {
        $serviceData = AccountUsageService::getInstance()->getActiveusersWeekly($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        } else {
            $this->responseJson('activeuserweekly', $serviceData['data']);
        }
    }

    /**
     * controller for accountusage of options
     *
     * @access public
     */
    public function options()
    {
        $serviceData = AccountUsageService::getInstance()->getOptions($this->requestParams);
        $this->responseJson('options', $serviceData['data']);
    }
}
