<?php

/**
 * Telemetry
 * 定义Telemetry接口
 * @author wanghu1209@thundersoft.com
 */

namespace Module\v1\controller;


use Module\adapter\service\impl\TelemetryService;
use Module\common\config\AdapterParamKeys;
use Module\common\controller\ApiBaseController;

class Telemetry extends ApiBaseController
{
    public function ftusum()
    {
        $serviceData = TelemetryService::getInstance()->getFtuSum($this->requestParams);
        $this->responseJson('ftusum', $serviceData['data']);
    }

    public function ftudaily()
    {
        $serviceData = TelemetryService::getInstance()->getFtuDaily($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        }else {
            $this->responseJson('ftudaily', $serviceData['data']);
        }
    }

    public function ftuoptions()
    {
        $serviceData = TelemetryService::getInstance()->getFtuOptions($this->requestParams);
        $this->responseJson('ftuoptions', $serviceData['data']);
    }
}