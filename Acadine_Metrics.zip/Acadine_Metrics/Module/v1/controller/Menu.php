<?php
/**
 * Menu
 * 定义菜单接口，返回菜单信息
 * @author wanghu1209@thundersoft.com
 */

namespace Module\v1\controller;

use Module\common\config\MenuConfig;
use Module\common\controller\ApiBaseController;

class Menu extends ApiBaseController
{
    public function get()
    {
        $this->app->response->setBody(json_encode([
            'status' => 200,
            'errno' => 0,
            'info' => MenuConfig::getMenuConfig(),
        ]));
    }
}
