<?php
/**
 * Login
 * 生成应用office365登录地址
 * @author maxc1216@thundersoft.com
 */

namespace Module\v1\controller;

use Core\lib\Config;
use Core\lib\Controller;
use Module\User\service\impl\UserService;

class Login extends Controller
{
    /**
     * 生成office365登录地址
     *
     * @param array $params
     */
    public function office365($params)
    {
        if (!count($params)) {
            return;
        }

        $tenantId = Config::get('ACC_OF_TENANT_ID');
        $clientId = Config::get('ACC_OF_CLIENT_ID');
        $redirectUri = Config::get('APP_HOST').'/v1/auth/office365/'.$params[0].'/';
        $loginUrl = UserService::OFFICE365_LOGIN_HOST.$tenantId.'/oauth2/authorize?response_type=code&client_id='.$clientId.'&state=&redirect_uri='.urlencode($redirectUri);
        $this->app->redirect($loginUrl);
    }
}
