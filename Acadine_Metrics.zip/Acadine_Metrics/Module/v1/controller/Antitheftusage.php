<?php
/**
 * Antitheftusage
 * antitheft usage 控制器，定义 antitheft usage 的各种接口
 * @author wanghu1209@thundersoft.com
 */

namespace Module\v1\controller;

use Module\common\config\AdapterParamKeys;
use Module\common\controller\ApiBaseController;
use Module\adapter\service\impl\AntitheftUsageService;

/**
 * Antitheftusage controller
 */
class Antitheftusage extends ApiBaseController
{

    /**
     * this function is the controller for Antitheftusage of enabledsum
     *
     * @access public
     */
    public function enabledsum()
    {
        $serviceData = AntitheftUsageService::getInstance()->getEnabledSum($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        } else {
            $this->responseJson('enabledsum', $serviceData['data']);
        }
    }

    /**
     * this fuction is the controller for Antitheftusage of lockdaily
     *
     * @access public
     */
    public function lockdaily()
    {
        $serviceData = AntitheftUsageService::getInstance()->getLockDaily($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        } else {
            $this->responseJson('lockdaily', $serviceData['data']);
        }
    }

    /**
     * this fuction is the controller for Antitheftusage of wipedaily
     *
     * @access public
     */
    public function wipedaily()
    {
        $serviceData = AntitheftUsageService::getInstance()->getWipeDaily($this->requestParams);
        if ($serviceData['format'] == AdapterParamKeys::FORMAT_CSV) {
            $this->responseCsv($serviceData['fileName'], $serviceData['data']);
        } else {
            $this->responseJson('wipedaily', $serviceData['data']);
        }
    }

    /**
     * this function is the controller for Antitheftusage of deviceoptions
     *
     * @access public
     */
    public function deviceoptions()
    {
        $serviceData = AntitheftUsageService::getInstance()->getDeviceOptions();
        $this->responseJson('deviceoptions', $serviceData['data']);
    }
}
