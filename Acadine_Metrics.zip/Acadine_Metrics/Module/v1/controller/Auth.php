<?php
/**
 * Auth
 * 定义用户登陆接口
 * @author maxc1216@thundersoft.com
 */

namespace Module\v1\controller;

use Core\lib\Controller;
use Module\common\exception\ParameterException;
use Module\User\service\impl\UserService;

class Auth extends Controller
{
    const ACC_SYS_OFFICE365 = 'office365';

    /**
     * login.
     *
     * @throws ParameterException
     */
    public function office365($params)
    {
        $code = $this->app->request->get('code');
        if ( is_null($code) || !count($params)) {
            $this->app->response->redirect('/');

            return;
        }
        try {
            $token = UserService::getInstance()->login($code, $params[0], self::ACC_SYS_OFFICE365);
            $this->app->setCookie('token', $token);
        } catch (\Exception $e) {
        }
        // 跳转首页
        $this->app->response->redirect('/');
    }
}
