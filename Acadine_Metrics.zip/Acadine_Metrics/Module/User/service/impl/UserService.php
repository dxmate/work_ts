<?php
/**
 * UserService
 * 用户的数据服务
 * @author maxc1216@thundersoft.com
 */

namespace Module\User\service\impl;

use Core\common\HttpException;
use Core\common\oauth2\OAuth2Client;
use Core\common\Singleton;
use Core\lib\Config;
use Module\common\ErrorNo;
use Module\common\exception\ServiceException;
use Module\User\model\impl\UserModel;
use Module\User\service\IUserService;
use Module\User\vo\LoginUser;

class UserService extends Singleton implements IUserService
{
    const EXPIRE_TIME = 86400 * 30;

    const OFFICE365_LOGIN_HOST = 'https://login.microsoftonline.com/';

    /**
     * get user service instance.
     *
     * @return \Module\User\service\impl\UserService
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\User\service\IUserService::login()
     */
    public function login(string $code, string $org, string $accSys)
    {
        $tenantId = Config::get('ACC_OF_TENANT_ID');
        $tokenApiUrl = self::OFFICE365_LOGIN_HOST.$tenantId.'/oauth2/token';
        $client = new OAuth2Client([
            'accessTokenUrl' => $tokenApiUrl,
            'redirectUri' => Config::get('APP_HOST').'/v1/auth/'.$accSys.'/'.$org.'/',
            'clientId' => Config::get('ACC_OF_CLIENT_ID'),
            'clientSecret' => Config::get('ACC_OF_CLIENT_SECRET'),
            'resource' => Config::get('ACC_OF_RESOURCE'),
        ]);

        try {
            $accessToken = $client->getAccessToken($code);
        } catch (HttpException $e) {
            throw $e;
        } catch (\Exception $e) {
            throw new ServiceException(null, ErrorNo::ERR_OAUTH2_CODE);
        }
        $idToken = $accessToken->getIdToken();
        $idTokenArr = explode('.', $idToken);
        $userInfo = json_decode(base64_decode($idTokenArr[1]), true);
        $loginUser = new LoginUser();
        $loginUser->org = $org;
        $loginUser->accSys = $accSys;
        $loginUser->oid = $userInfo['oid'];
        $loginUser->name = $userInfo['name'];
        $loginUser->email = $userInfo['unique_name'];
        $token = $this->addLoginUser($loginUser);

        return $token;
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\User\service\IUserService::logout()
     */
    public function logout(string $token)
    {
        UserModel::getInstance()->deleteToken($token);
    }

    /**
     * {@inheritdoc}
     *
     * @see \Module\User\service\IUserService::getLoginUserByToken()
     */
    public function getLoginUserByToken(string $token)
    {
        return UserModel::getInstance()->getLoginUserByToken($token);
    }

    /**
     * add login user.
     *
     * @param LoginUser $user
     * @param int       $expireTime
     *
     * @return string
     */
    private function addLoginUser(LoginUser $user, int $expireTime = self::EXPIRE_TIME)
    {
        $token = guid();
        UserModel::getInstance()->addLoginUser($user, $token, $expireTime);

        return $token;
    }
}
