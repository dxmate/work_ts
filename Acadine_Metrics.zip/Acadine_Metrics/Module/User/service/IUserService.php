<?php
/**
 * IUserService
 * 用户的数据服务接口
 * @author maxc1216@thundersoft.com
 */

namespace Module\User\service;

interface IUserService
{
    /**
     * login.
     *
     * @param string $code    This code is the parameter that is returned by the office 365.
     * @param string $org     organization.
     * @param string $accSys  account system.
     *
     * @return string
     */
    public function login(string $code, string $org, string $accSys);

    /**
     * logout.
     *
     * @param string $token
     */
    public function logout(string $token);

    /**
     * get local user infomation .
     *
     * @param string $token
     *
     * @return LoginUser
     */
    public function getLoginUserByToken(string $token);
}
