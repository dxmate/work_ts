<?php
/**
 * IUserModel
 * 用户的数据模型接口
 * @author maxc1216@thundersoft.com
 */

namespace Module\User\model;

use Module\User\vo\LoginUser;

interface IUserModel
{
    /**
     * add login user.
     *
     * @param LoginUser $user
     * @param string    $token
     * @param int       $expireTime
     */
    public function addLoginUser(LoginUser $user, string $token, int $expireTime);

    /**
     * Go to office365 to get access_token by code.
     *
     * @param string $code
     *
     * @throws ServerException
     *
     * @return string
     */
    public function getAccessTokenByCode(string $code);

    /**
     * get local user infomation.
     *
     * @param string $token
     *
     * @return LoginUser | null
     */
    public function getLoginUserByToken(string $token);

    /**
     * delete token stored in redis.
     *
     * @param string $token
     */
    public function deleteToken(string $token);
}
