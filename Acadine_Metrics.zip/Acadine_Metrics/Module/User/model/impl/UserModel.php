<?php
/**
 * UserModel
 * 用户的数据模型
 * @author maxc1216@thundersoft.com
 */

namespace Module\User\model\impl;

use Core\common\HttpClient;
use Core\common\Singleton;
use Core\lib\Cache;
use Core\lib\Config;
use Module\User\model\IUserModel;
use Module\User\vo\LoginUser;

class UserModel extends Singleton implements IUserModel
{
    const FIELD_ORG = 'org';

    const FIELD_ACC_SYS = 'acc_sys';

    const FIELD_UID = 'uid';

    const FIELD_NAME = 'name';

    const FIELD_EMAIL = 'email';

    /**
     * get user model instance.
     *
     * @return \Module\User\model\impl\UserModel
     */
    public static function getInstance()
    {
        return parent::getInstance();
    }

    /**
     * add user info.
     *
     * @param LoginUser $user
     * @param string    $token
     * @param int       $expireTime
     */
    public function addLoginUser(LoginUser $user, string $token, int $expireTime)
    {
        $data = [
            self::FIELD_ORG => $user->org,
            self::FIELD_ACC_SYS => $user->accSys,
            self::FIELD_UID => $user->oid,
            self::FIELD_NAME => $user->name,
            self::FIELD_EMAIL => $user->email
        ];
        $val = json_encode($data);
        $redis = Cache::redis();
        $redis->setex($token, $expireTime, $val);
    }

    /**
     * Go to office365 to get access_token by code.
     *
     * @param string $code
     *
     * @return string
     */
    public function getAccessTokenByCode(string $code)
    {
        $data['client_id'] = Config::get('ACC_OF_CLIENT_ID');
        $data['client_secret'] = Config::get('ACC_OF_CLIENT_SECRET');
        $data['code'] = $code;
        $data['grant_type'] = 'authorization_code';
        $data['redirect_uri'] = Config::get('ACC_OF_URI');
        $data['resource'] = Config::get('ACC_OF_RESOURCE');
        $result = HttpClient::getInstance()->post(Config::get('ACC_OF_API_URL'), $data)->getBody();

        return $result;
    }

    /**
     * get local user infomation.
     *
     * @param string $token
     *
     * @return LoginUser | null
     */
    public function getLoginUserByToken(string $token)
    {
        $redis = Cache::redis();
        $result = $redis->get($token);
        if (is_null($result)) {
            return;
        }
        $userInfo = json_decode($result, true);
        $loginUser = new LoginUser();
        $loginUser->org = $userInfo[self::FIELD_ORG];
        $loginUser->accSys = $userInfo[self::FIELD_ACC_SYS];
        $loginUser->oid = $userInfo[self::FIELD_UID];
        $loginUser->name = $userInfo[self::FIELD_NAME];
        $loginUser->email = $userInfo[self::FIELD_EMAIL];

        return $loginUser;
    }

    /**
     * delete token stored in redis.
     *
     * @param string $token
     */
    public function deleteToken(string $token)
    {
        $tokenArr = [
            $token,
        ];
        $redis = Cache::redis();
        $redis->del($tokenArr);
    }
}
