<?php
/**
 * LoginUser
 * 定义登陆用户的基本信息
 * @author maxc1216@thundersoft.com
 */

namespace Module\User\vo;

class LoginUser
{
    public $oid;

    public $email;

    public $name;

    public $org;

    public $accSys;

    public $isAdmin = false;

    public $authorities = [];
}
