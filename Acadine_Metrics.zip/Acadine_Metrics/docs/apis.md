# 公共约定
## 接口返回值数据格式
所有接口若有返回值，约定为json格式，如下
```json
{
    "status":200,
    "errno":0,
    "msg":"提示信息",
    "info":[]
}
```
字段|类型|说明|
---|---|---
status|int|与http状态码和含义保持一致
errno|int|系统定义的唯一错误码
msg|string|提示信息，可以直接用于给用户提示，也可以根据错误码含义自定义提示信息
info|object|若接口有数据业务返回，将放置在该字段中；同时发生错误时可以作为msg的补充
### 注意事项
如果返回status为302时，由于ajax无法像浏览器一样重定向，这时info字段中会包含需要跳转的url信息，前端ajax收到数据后统一做跳转;
其他情况我们关心errno就可以; errno只要不为0时表示有异常，可以把msg字段里的信息给用户提示

## 错误码

错误码|说明
-----|----
0|正常，无错误信息
101|json数据格式错误
102|包含非法参数
103|缺少必要参数
104|包含未知含义的参数
121|用户认证失败或缺少认证信息,可以理解为未登录，这个时候会在info中返回登录地址，前端做跳转
141|用户没有权限或权限不足
161|接口不存在
201|系统内部错误
201|系统内部错误
203|数据服务器接口调用网络错误
204|数据服务器接口返回数据格式错误
————|


# 接口部分
## Table of content
* [Get menu](#get-menu)
* [Get accountusage validatedusersdaily](#get-accountusage-validatedusersdaily)
* [Get accountusage validateduserstotal](#get-accountusage-validateduserstotal)
* [Get accountusage activeusersdaily](#get-accountusage-activeusersdaily)
* [Get accountusage activeusersweekly](#get-accountusage-activeusersweekly)
* [Get accountusage options](#get-accountusage-options)
* [Get antitheftusage enabledsum](#get-antitheftusage-enabledsum)
* [Get antitheftusage lockdaily](#get-antitheftusage-lockdaily)
* [Get antitheftusage wipedaily](#get-antitheftusage-wipedaily)
* [Get antitheftusage deviceoptions](#get-antitheftusage-deviceoptions)
* [GET telemetry ftusum](#get-telemetry-ftusum)
* [GET telemetry ftudaily](#get-telemetry-ftudaily)
* [GET telemetry ftuoptions](#get-telemetry-ftuoptions)

## get-menu
### GET /v1/menu/get

__Parameters__

none

__Response__
```js
{
    "status":200,
    "errno":0,
    "info":[
        {
            "text":"Smart Feature Phone",
            "icon":"",
            "children":[
                {
                    "text":"Activation",
                    "icon":"",
                    "url":"/pages/sfp/sfp-activation.html",
                    "children":[]
                }
            ]
        }
    ]
}
```
正常情况 url 字段如果为空字符串，children 就应该不为空数组



## get-accountusage-validatedusersdaily
Query daily validated users from a given date and end date.
### GET /v1/accountusage/validatedusersdaily

__Parameters__

* startDate - start date, such as 2016-03-01
* endDate - end date, such as 2016-05-01
* _format_ - optional, result format which is json by default, csv is the another option
* _referer_ - optional, referer list separated by comma

__Response__

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
        "description":"Daily Validated Users",
        "startDate":"2016-03-15",//the first available date
        "endDate":"2016-05-25",//the latest available date
        "data":[
            {
                "date":"2016-03-15",
                "count":220
            },
            {
                "date":"2016-03-16",
                "count":120
            }
        ]
    }
}
```

## get-accountusage-validateduserstotal
Query daily validated users from a given date and end date.
### GET /v1/accountusage/validateduserstotal

__Parameters__

* startDate - start date, such as 2016-03-01
* endDate - end date, such as 2016-05-01
* _format_ - optional, result format which is json by default, csv is the another option
* _referer_ - optional, referer list separated by comma

__Response__

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
        "description":"Total Validated Users",
        "startDate":"2016-03-15",//the first available date
        "endDate":"2016-05-25",//the latest available date
        "data":[
            {
                "date":"2016-03-15",
                "count":220
            },
            {
                "date":"2016-03-16",
                "count":120
            }
        ]
    }
}
```

## get-accountusage-activeusersdaily
Query daily active users from a given start date to end date.
### GET /v1/accountusage/activeusersdaily

__Parameters__

* startDate - start date, such as 2016-03-01
* endDate - end date, such as 2016-05-01
* _format_ - optional, result format which is json by default, csv is the another option
* _referer_ - optional, referer list separated by comma

__Response__

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
        "description":"Daily Active Users",
        "startDate":"2016-03-15",//the first available date
        "endDate":"2016-05-25",//the latest available date
        "data":[
            {
                "date":"2016-03-15",
                "count":220
            },
            {
                "date":"2016-03-16",
                "count":120
            }
        ]
    }
}
```


## get-accountusage-activeusersweekly
Query weekly active users from a given start week to end week.
### GET /v1/accountusage/activeusersweekly

__Parameters__

* startWeek - start week(week count of year), such as 20
* endWeek - end week, such as 30
* _format_ - optional, result format which is json by default, csv is the another option
* _referer_ - optional, referer list separated by comma


__Response__

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
         "description": "Weekly Active Users",
         "startWeek": 23, // the first available week
         "endWeek": 29, // the latest available week
         "data": [{
              "week": 23,
              "count": 220
              }, {
              "date": 24,
              "count": 120
              }]
         }
}
```

## get-accountusage-options
Query available options for given params.
### GET /v1/accountusage/options

__Parameters__

* _params_ - param list separated by comma

__Response__

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
         "referer": ["AccountWebsite",
         "AntiTheft", "GoFlip", "GoFlip2"],
         "device": ["GoFlip", "GoFlip2"],
         "service": ["Account"],
    }
}
```

## Get-antitheftusage-enabledsum
Query how many devices/users enabled AntiTheft.
### GET /v1/antitheftusage/enabledsum

__Parameters__

* startDate - start date
* endDate - end date
* _format_ - optional, result format which is json by default, csv is the another option
* _device_ - optional, device list separated by comma

### Response

Data in JSON format:

```js

{
    "status":200,
    "errno":0,
    "info":{
        "description": "AntiTheft Enabled Users and Devices",
        "startDate": "2016-03-15", // the first available date
        "endDate": "2016-05-25", // the latest available date
        "device": ["GoFlip", "GoFlip2"],
        "data": [{
            "date": "2016-03-15",
            "usercount": 220,
            "devicecount": 380,
        }, {
            "date": "2016-03-16",
            "usercount": 120,
            "devicecount": 180,
        }]
    }
}
```
## Get-antitheftusage-lockdaily
Query how many users used lock feature.
### GET /v1/antitheftusage/lockdaily

__Parameters__

* startDate - start date
* endDate - end date
* _format_ - optional, result format which is json by default, csv is the another option
* _device_ - optional, device list separated by comma

### Response

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
        "description": "AntiTheft Lock Usage",
        "startDate": "2016-03-15", // the first available date
        "endDate": "2016-05-25", // the latest available date
        "data": [{
            "date": "2016-03-15",
            "usercount": 220,
            "actioncount": 380,
        }, {
            "date": "2016-03-16",
            "usercount": 120,
            "actioncount": 180,
        }]
    }
}
```

## Get-antitheftusage-wipedaily
Query how many users used wipe feature.
## GET /v1/antitheftusage/wipedaily

__Parameters__

* startDate - start date
* endDate - end date
* _format_ - optional, result format which is json by default, csv is the another option
* _device_ - optional, device list separated by comma

### Response

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
        "description": "AntiTheft Wipe Usage",
        "startDate": "2016-03-15", // the first available date
        "endDate": "2016-05-25", // the latest available date
        "data": [{
            "date": "2016-03-15",
            "usercount": 220,
            "actioncount": 380,
        }, {
            "date": "2016-03-16",
            "usercount": 120,
            "actioncount": 180,
        }]
    }
}
```
## Get-antitheftusage-deviceoptions
Get available device options.
### GET /v1/antitheftusage/deviceoptions

__Parameters__

None

### Response

The available device list will be returned in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":["GoFlip", "GoFlip2", "H5Watch",
            "Others"]
}
```
## Get-telemetry-ftusum
Query total FTU number from a given start date and end date.
### GET /v1/telemetry/ftusum

__Parameters__

* startDate - start date
* endDate - end date
* _os_ - optional, os list separated by comma
* _device_ - optional, device list separated by comma
* _operator_ - optional, operator list separated by comma
* _country_ - optional, country list separated by comma
* _chipset_ - optional, chipset list separated by comma

### Response

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
        "description": "FTU Sum",
        "startDate": "2016-03-01",
        "endDate": "2016-05-30",   // the latest available date will be filled if it's not the same as the given endDate
        "country": ["us,uk"],
        "chipset": ["qcom"],
        "count": 4323
    }
}
```

## Get-telemetry-ftudaily
Query daily FTU from a given start date and end date.
### GET /v1/telemetry/ftudaily

__Parameters__

* startDate - start date
* endDate - end date
* _format_ - optional, result format which is json by default, csv is the another option
* _os_ - optional, os list separated by comma
* _device_ - optional, device list separated by comma
* _operator_ - optional, operator list separated by comma
* _country_ - optional, country list separated by comma
* _chipset_ - optional, chipset list separated by comma

### Response

Data in JSON format:

```js
{
    "status":200,
    "errno":0,
    "info":{
       "description": "Daily FTU",
       "startDate": "2016-03-01",
       "endDate": "2016-05-28",   // the latest available date will be filled if it's not the same as the given endDate
       "country": ["us,uk"],
       "chipset": ["qcom"],
       "data": [{
            "date": "2016-03-01",
            "count": 120
      }, {
            "date": "2016-03-02",
            "count": 100
       }, {
            "date": "2016-03-03",
            "count": 108
        }]
    }
}
```

## Get-telemetry-ftuoptions
Get the available options for the given param(s) supported by endpoint [GET /telemetry/v1/ftu/daily](#get-telemetry-ftudaily), all the available options of all the params will be returned if query string is empty.
### GET /v1/telemetry/ftuoptions

__Parameters__

* _params_ - param list separated by comma

### Response

```js
{
    "status":200,
    "errno":0,
    "info":{
        "country": ["us","uk"],
        "chipset": ["qcom","mtk"],
        "os": ["windows","linux"],
        "device": ["phone","ipad"],
        "operator": ["acadine","h5"]
    }
}
```