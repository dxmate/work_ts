## 目录结构
目录|说明|
--------|---
Core    |框架基础，与业务无关
Module  |后台业务模块，不同模块以不同目录形式体现
pages   |前端源码目录
public  |项目访问入口，域名绑定到该目录
tests   |unit测试目录
docs    |项目涉及到的文档目录

## 部署
* 环境
    * php7.0或以上，curl扩展必须是enabled
    * redis
    * openresty或nginx
* 安装npm, bower以及gulp
* 运行 composer install --no-dev
* 运行bower install;npm install;gulp
* 访问域名绑定到public目录，同时nginx配置需要加上
```
  try_files $uri $uri/ /index.php?$query_string;
```
## 配置
将env.example拷贝一份改名为 .env, 将redis的配置按实际情况修改，下面是部分配置项介绍
配置项 |说明
------------|---
APP_HOST    |应用根地址，例如 http://dashboard.ac
API_HOST_ACCOUNT|account接口根地址，例如 http://acadinedev.com
ACC_OF_TENANT_ID|office365商户ID
ACC_OF_CLIENT_ID|在office365中的client_id
ACC_OF_CLIENT_SECRET|在office365中的client_secret

office365中的redirect_uri配置为http://metrics域名/v1/auth/office365/acadine/